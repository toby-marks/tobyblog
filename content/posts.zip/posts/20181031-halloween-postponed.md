+++
title = "Halloween is Officially On Hold"
description = "Try again next year."
date = "2018-10-31T09:34:28-05:00"
externalurl = "https://www.youtube.com/watch?v=JqPjtaNoChs"
categories = ["Music"]
tags = ["Halloween", "Bruno Martino"]
+++
October, you have been one long, soggy mess. C'est la vie, I suppose. To commemorate what I anticipate to be tonight's non-event, I have chosen this song to be the official "hold" music of Halloween 2018, to be played in a continuous loop until one metaphorically throws up one's hands in disgust, and finally gives up the game. To pick it up again next year? Perhaps. But never quite in the same way.

{{< youtube JqPjtaNoChs >}}
