+++
title = "Live Forever"
description = ""
date = "2020-04-15T11:05:44-05:00"
categories = ["Books"]
tags = ["Ray Bradbury"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1586966702/img/IMG_6769.jpg" >}}

This popped up on my Twitter this morning from a unexpected and practically random source. The following story is told in Sam Weller's biography of Ray Bradbury.

<!--more-->
He's talking about a character from one of his novels, Mr. Electrico, who was based on an actual person he met in his childhood, an event that would shape the rest of his life.

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1586966310/img/IMG_6764.png" >}}

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1586966300/img/IMG_6765.png" >}}

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1586966293/img/IMG_6766.png" >}}

Bradbury was deeply in tune with the undercurrent of *real* magic that exists right below the surface of the everyday. He would go on to meet, read, and write about many other people who played formative roles in shaping his mind and spirit over the years, but I wonder if Mr. Electrico ever met any other kid like young Ray Bradbury.