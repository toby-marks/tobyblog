+++
categories = ["Reviews"]
date = "2019-03-14T22:57:00+00:00"
description = "A review of Taco Libre in Old Town Pasadena"
tags = ["Pasadena","California","travel", "food"]
title = "Taco Libre"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552629476/img/576933C9-5E92-4C23-B1AF-8B342EF82BDF.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552629476/img/576933C9-5E92-4C23-B1AF-8B342EF82BDF.jpg" >}}

The weather was warmer today. I could feel spring in my bones. I get that way around this time of year. Maybe I was feeling a little homesick. Whatever the case, I've been craving Mexican food. I noticed this little while walking around during my lunch break. 

As I was standing outside the door reading the posted menuboard, an older lady passing by said to me "Go in. You'll like it. It's really good." I took that as a sign.
<!--more-->

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552629608/img/5BFDCAF7-9CBF-4CD7-915A-877315CEDD06.jpg" >}}

The place had very limited seating, but at 6:00pm I had it all to myself. I ordered two of the "Gubernador", basically fancy shrimp tacos with a light and pleasant cream sauce. I noticed some Tajin on a shelf behind the counter, so I asked them to reach it for me. It provided a little extra seasoning for the shrimp.

And they had Topo. God bless these people. I could have had a cerveza, I suppose, but I wasn't feeling it today.

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552629687/img/6A681B49-CC2B-4D86-BEE8-4FC5BD2C3E6D.jpg" >}}

The tacos were fantastic. That sauce made all the difference. The soft corn tortillas held up, too. No splitting or crumbling. I ordered chips and guacamole and the guac was especially good, I thought. A bit more garlic in it than at the El Portal, which is a good thing, trust me.

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552629508/img/241EA444-4B47-4456-88DA-D525C6879F99.jpg" >}}

*Rating:* Superior. I will absolutely be back. Tacos a little on the expensive side, but you get what you pay for.
