+++
title = "Real Life Pokemon on my Walk"
description = ""
date = "2020-06-25T18:04:39-05:00"
categories = ["Journal"]
tags = ["pokemon"]
minipost = "true"
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1593126461/img/IMG_7325.jpg" >}}

Evolved my Ekans into a Daehreppoc. 🐍  *Not bad, huh?*

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1593126470/img/IMG_7331.jpg" >}}

But this was my luckiest catch of the day.

*CORONAVIRUS, I CHOOSE YOU!*

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1593126842/img/Unknown.jpg" >}}