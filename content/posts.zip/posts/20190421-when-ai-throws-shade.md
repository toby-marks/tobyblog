+++
title = "The Hidden Dangers of AI"
description = ""
date = "2019-04-21T15:50:15-05:00"
categories = ["Journal"]
minipost = "true"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1555879858/img/chubby.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1555879858/img/chubby.jpg" >}}

What exactly are you trying to tell me, Facebook?
