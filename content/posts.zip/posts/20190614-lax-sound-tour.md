+++
categories = ["Audio"]
date = "2019-06-14T16:54:34-07:00"
description = "Join me on a soundseeing tour of LAX airport"
draft = false
minipost = "true"
tags = ["LAX", "travel","Los Angeles","Pasadena","California"]
title = "A New Thing?"

+++
I decided to do something today I've been wanting to do for quite a while. I'm bringing back what they used to call in the early days of podcasting "soundseeing tours", wherein people just recorded the ambient sounds of interesting places they visited or things they were doing. Not much time to do a writeup on this, as I'm about to board my flight, but here you can join me on my customary walk from Tom Bradley International terminal across the length and breadth of the airport. 

Along the way are a few surprises. See if you can spot

* Neil Diamond 
* Clicking heels of an army of Korean flight attendants
* A random dude that just happened to be playing the piano as I passed by
* A very special pit stop
* Natalie Merchant

*Enjoy!*

<iframe width="100%" height="300" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/636842547&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"></iframe>
