+++
title = "Today's Sounds: It's Possible"
description = ""
date = "2020-11-04T12:07:29-06:00"
externalurl = "https://www.youtube.com/watch?v=lDf4DfhUUBw"
categories = ["Music"]
tags = ["youtube"]
+++
Forever remind yourself.
 
{{< youtube lDf4DfhUUBw >}}

The comments section on this video describes it as 70's Italian cocaine lounge music. Psychedelia. Dunno, but I like it. I suppose this goes out to all you folks tripping today in Oregon.