+++
categories = ["Audio"]
date = "2019-09-10T17:52:50-05:00"
description = ""
minipost = true
tags = ["Halloween", "toys"]
title = "My Favorite Halloween Toy of 2019"
+++
🎃📻🧡

{{< youtube F5rr0dmGV5Q >}}
