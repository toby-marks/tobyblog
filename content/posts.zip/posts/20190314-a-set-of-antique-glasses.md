+++
date = "2019-03-14T22:55:00+00:00"
title = "A Set of Antique Glasses"
categories = ["Journal"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552629327/img/0F2A9E95-BB97-45F8-AB3F-FDFB1C597932.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552629327/img/0F2A9E95-BB97-45F8-AB3F-FDFB1C597932.jpg" >}}

I always check out the glassware in antique shops. The Greek theme doesn't really suit me, but I thought the ornate styling was good for a pic.
