+++
title = "When did people first start mowing lawns?"
date = "2018-04-08T14:16:37-05:00"
categories = ["Journal"]
minipost = true
+++
Today I mowed the back yard for the first time this spring. I am behind. The weather and other duties had kept me off task. The grass was high, and each square foot I tread into submission was like a territory reclaimed for civilization. 

I asked myself when people started doing this whole thing. Exactly how old is the time honored American activity of mowing the lawn? And why is this mundane chore, as therapeutic and contemplative as it is, not shown more love by those in the Big Nostalgia set, so connected as it is to real childhood and adolescent memory? Where does it all come from? 

{{< youtube mfgXiK6KBLU >}}