+++
title = "Slavoj Zizek on The Joker"
description = ""
date = "2019-11-06T18:03:06-06:00"
externalurl = "https://www.youtube.com/watch?v=UXfLafgzoX0"
categories = ["Journal"]
tags = ["news"]
+++
He's not a fan of the new Joker, though he greatly admires Nolan's version. 

> The truth is in your mask. The truth is in what you are doing.

Interesting take.

> Paradoxically, a mask means I can be who I really am.

His point, based in some psychological theory, is that our plain faces are the real masks; that in our normal lives we artificially conform ourselves because of social convention, expectations, etc; but that "our mask" allows us to break out of those restrictions, inviting the true self – the inner or even unconscious self – to emerge. 

Zizek is at his most entertaining and thought provoking when doing this kind of movie criticism, IMO. 

{{< youtube "UXfLafgzoX0" >}}
