+++
title = "The Intelligence of Corvids"
description = ""
date = "2020-01-06T14:26:52-06:00"
externalurl="https://www.bbc.com/future/article/20191211-crows-could-be-the-smartest-animal-other-than-primates"
categories = ["News"]
tags = ["crows", "corvids", "science"]
+++
> Crows, in fact, might be like us not so much because they are clever (and so are we) but rather because they sometimes engage their cleverness simply for fun – and so do we.

What's it like to be a crow? What do they make of us? Are animals capable of moral behavior? Having been a pet owner for many years I think this is true. I feel I've observed it. But then again there are some folks who think that *everything* is capable of an existential morality, even the non-animate creation.
