+++
title = "So Long, San Francisco"
description = "A song to leave San Francisco by"
date = "2018-10-26T00:24:11-05:00"
externalurl = "https://www.youtube.com/watch?v=Y5MG4TnmdoQ"
categories = ["Music"]
tags = ["Glenn Yarbrough"]
+++
A song to fit a very particular mood. It's been a significant week.

{{< youtube Y5MG4TnmdoQ >}}
