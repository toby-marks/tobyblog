+++
categories = ["News"]
date = 2019-11-19T20:21:09Z
description = ""
draft = true
externalurl = "https://www.bbc.com/news/newsbeat-50473092"
tags = ["comics"]
title = "Alan Moore, Creator of The Watchmen, Says Adult Infatuation With Comic Book Superheros is Embarassing"

+++
> He adds the popularity of the genre among adults suggests a "kind of deliberate, self-imposed state of emotional arrest".
>
> And his criticism extends to creators.
>
> He says superheroes are written and drawn by people who've never stood up for their own rights against the companies that employ them - saying they appear "to be largely employed as cowardice compensators".

The culture is dumbing down, becoming more juvenile, and this is just one manifestation of that. 

I like his interpretation of heroes as "cowardice compensators". He seemed to be making a specific reference to conditions in the comic publishing business, but I wonder if it's true in a larger sense, for the people who create comics and for the broader culture. I'd like to see more of that kind of psycho-social analysis.