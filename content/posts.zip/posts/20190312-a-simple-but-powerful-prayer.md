+++
categories = ["Journal"]
date = "2019-03-12T07:00:00+00:00"
description = "Fr. Lazarus El Antony talks about the Jesus Prayer."
tags = ["religion","Orthodox"]
title = "A Simple But Powerful Prayer "
minipost = "true"
+++
{{< youtube ccAaMhSW_PY >}}
