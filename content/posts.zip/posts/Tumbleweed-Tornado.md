+++
title = "Desert Tornado"
description = ""
date = "2020-05-06T10:59:53-05:00"
categories = ["News"]
tags = [""]
externalurl = "https://www.atlasobscura.com/articles/what-is-a-tumbleweed-tornado"
+++
I don't know, I thought this was kind of neat.

{{< youtube Ay3tEQDZSmM >}}