+++
title = "Pretty People"
description = ""
date = "2020-07-30T21:36:57-05:00"
categories = ["Music"]
tags = [""]
minipost = "true"
externalurl = "https://www.youtube.com/watch?v=qxuRiniFx9c"
+++
Currently enjoying this sweet cover of one of my favorite Blossom Dearie tracks. That's [not the only Blossom Dearie song](https://www.youtube.com/watch?v=ipeztjJjQm4) they cover, too. Apparently somebody over there is a fan.

If there were more covers of her music I'd love to do another cover battle, but alas. Blossom is too much underappreciated.

{{< youtube qxuRiniFx9c >}}
