+++
title = "Kassi Blogs the Plano Balloon Fest"
description = ""
date = "2019-11-05T15:57:35-06:00"
externalurl = "https://kassiblogtoo.blogspot.com/2019/11/plano-balloon-festival-2019.html"
categories = ["Journal"]
tags = ["Kassi"]
images = ["https://1.bp.blogspot.com/-L-u_MScQaLY/XcHJ8KEWBhI/AAAAAAAADgs/ISJVh1mfm4wsYqNzO0kaLJ00HYZXccrogCEwYBhgL/s640/IMG_5220.jpg"]
+++
Because I wanted to share her picture of me stuffing my face with a gigantic turkey leg. Also, 'Murica.

{{< picture alt="" src="https://1.bp.blogspot.com/-L-u_MScQaLY/XcHJ8KEWBhI/AAAAAAAADgs/ISJVh1mfm4wsYqNzO0kaLJ00HYZXccrogCEwYBhgL/s640/IMG_5220.jpg" >}}
