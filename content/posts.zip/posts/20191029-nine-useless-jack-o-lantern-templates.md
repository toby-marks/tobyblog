+++
categories = ["Journal"]
date = "2019-10-29T23:00:00-05:00"
description = ""
tags = ["Halloween"]
title = "Nine Useless Jack O' Lantern Templates"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.47.10_PM.png"]
+++
{{< youtube LWJYaep-0sg >}}

Most of these were taken from the huge catalog of templates over at [Stoneykins.com](https://www.stoneykins.com/), the vast majority of which are pretty cool and definitely not useless. 
<!--more-->

### #9. Joker Joaquin Phoenix

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.52.23_PM.png" >}}

Not a bad idea, but it already looks like you messed it up. 

### #8. Boo-Tay

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.47.10_PM.png" >}}

This should not ever be done, for any reason.

### #7. Frank Sinatra Stein

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.50.26_PM.png" >}}

Ok. But why?

### #6. Two Youts

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.56.57_PM.png" >}}

Just because the judge from My Cousin Vinny was the same guy who played Herman Munster does not give this jack o' lantern a reason to exist.

### 5. Kim Jong Un

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.52.48_PM.png" >}}

Scary? Some kind of political statement? North Korean propaganda? What the hell is this.

### #4. Ruth Bader Ginsburg

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.54.57_PM.png" >}}

Are you scared yet? Because not even Halloween is safe from the RBG promotional juggernaut. You wanted your spooky time free of tiresome political posturing? ***Well she just dropped a dissenting opinion on your ass.***

### #3. Harvey Milk

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.51.27_PM.png" >}}

When you like #4, and you're gay.

### #2. Keith Olbermann

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.35.48_PM.png" >}}

When you like #4, and you really want your house covered in toilet paper.

### #1. Pope Francis

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1572452314/img/Screen_Shot_2019-10-29_at_5.43.39_PM.png" >}}

Just don't. Surely this has to be at the intersectional nexus of every single category of bad idea. Your Halloween and your Catholicism are now forever lamer. 
