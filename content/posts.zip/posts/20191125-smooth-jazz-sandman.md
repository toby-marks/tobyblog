+++
title = "Metallica-Enter Sandman (Smooth Jazz Version)"
description = ""
date = "2019-11-25T12:08:30-06:00"
externalurl = "https://www.youtube.com/watch?v=OBmM79YadYM"
categories = ["Music"]
tags = ["pop"]
+++
NEW PERMANENT MOOD.

{{< youtube OBmM79YadYM >}}
