+++
title = "Independence Day 2019"
date = "2019-07-04T11:00:00-05:00"
description = "My post"
categories = ["Journal"]
tags = ["4th of July"]
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1562256320/img/09474C58-625F-4B47-88CF-4798FDAEB69B.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1562256320/img/09474C58-625F-4B47-88CF-4798FDAEB69B.jpg" >}}

There’s no denying we live in troubled times in this country. Shared celebrations are a respite from the hate that seems set to smother our culture. They also serve as milestones, reminding us of the passage of time and providing a useful historical perspective on our own lives and the times we share with each other. For our part, we plan to celebrate like we haven’t in a while, venturing down to the mall later for the big party, then fireworks later tonight. Before that I’ll be grilling pizzas in the backyard, and I hope to get a lot of today on camera.
<!--more-->

So what are you doing to celebrate? I’d like to know. 
