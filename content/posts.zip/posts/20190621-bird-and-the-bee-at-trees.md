+++
title = "Guess Who's Coming to Dallas?"
description = "Bird and the Bee are coming to Trees in Deep Ellum on August 24, 2019."
date = "2019-06-21T21:33:03-05:00"
externalurl = "http://www.treesdallas.com/event/1867561-bird-bee-dallas/"
categories = ["Music"]
tags = ["Bird and the Bee"]
+++
Well, well. And I thought they'd retired. I suppose there are still a few living acts I'd pay to see after all. 🐦🐝  No idea whether we'll make it out to this one, but might bee nice.

[Read all about my love for their Hall and Oates cover album]({{< ref "20190220-bird-and-the-bee.md" >}}). And give those songs a deep listen.

{{< youtube lW8aFSchq4M >}}
