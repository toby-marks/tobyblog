+++
categories = ["Journal"]
date = "2019-04-12T12:00:00+00:00"
description = ""
externalurl = "https://www.creativeboom.com/resources/monotype-launches-the-first-redesign-in-35-years-of-the-worlds-most-ubiquitous-font-helvetica/"
tags = ["news"]
title = "Helvetica Now"
+++
> "Helvetica Now is the tummy-tuck, facelift and lip filler we’ve been wanting, but were too afraid to ask for,” said Abbott Miller