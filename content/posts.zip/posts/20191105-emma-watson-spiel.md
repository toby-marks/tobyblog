+++
title = "Hermione's Spiel"
description = ""
date = "2019-11-05T15:26:54-06:00"
externalurl = "https://time.com/5718757/emma-watson-self-partnered/"
categories = ["Journal"]
tags = ["news"]
+++
> She went on: “I never believed the whole ‘I’m happy single’ spiel. I was like, ‘This is totally spiel.’ It took me a long time, but I’m very happy [being single]. I call it being self-partnered.”

The only story here is how much Emma Watson uses the Hollywood word ***spiel***.
