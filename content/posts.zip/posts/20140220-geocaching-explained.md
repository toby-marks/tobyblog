+++
title = "Geocaching Explained"
date = 2014-02-20T21:46:00Z
categories = ["Hobbies"]
tags = ["geocaching"]
minipost = "true"
+++
{{< youtube 1YTqitVK-Ts >}}

Geocaching is one of my main hobbies. Since I'm going to be posting a lot about it, here's a formal introduction from Groundspeak, the company that runs the geocaching.com site.
