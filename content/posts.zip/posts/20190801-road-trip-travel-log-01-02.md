+++
categories = ["Journal"]
date = "2019-08-01T23:00:00-05:00"
description = ""
minipost = "true"
tags = ["travel","vacation","Texas","Albuquerque","New Mexico"]
title = "Road Trip Travel Log 01.02"
images = ["https://res.cloudinary.com/tobyblog/image/upload/a_0/v1564718661/img/64476DE9-F842-4C3E-A5FA-B9D13A537604_fjccxc.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1564718661/img/64476DE9-F842-4C3E-A5FA-B9D13A537604_fjccxc.jpg" >}}

Picture of me in the Llano Estacado, Texas’s “wine country”. On the road for quite a while and still not out of the state. Holding up well. Fear the little one may be coming down with a cold. Hope he’s better after some rest. 

Changed restaurant plans and will revisit our old favorite in Albuquerque for the third year in a row. 

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1564718915/img/2BC3A181-05ED-476E-9231-0163072E2684_mcgwmk.jpg" >}}

The food there has always been great, though the service is consistently slow. Had a very nice steak dinner and a just-OK Old Fashioned. I think I’m spoiled at the Wildwood back home. 

Tomorrow we hike at Red Rock State Park. Should be warm, but can’t possibly be as uncomfortably humid as when we left Dallas. Gonna try and grab some shut-eye. Real vacation starts tomorrow morning!

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1564719321/img/7708843D-BECC-4A35-A3A2-A0456789DD5A_lkosec.jpg" >}}
