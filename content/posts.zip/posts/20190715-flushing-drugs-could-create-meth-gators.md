+++
title = "COPS: Flushing Drugs Could Create “Meth-Gators”"
date = "2019-07-15T14:00:00-05:00"
externalurl = "https://www.al.com/news/huntsville/2019/07/police-flushing-drugs-could-create-alabama-meth-gators.html"
categories = ["Journal"]
tags = ["news"]
+++
The Alabama Meth-Gators is my new favorite college football team.
