+++
title = "A Day of Decisions"
date = 2014-04-18
categories = ["Journal"]
tags = ["Ray Bradbury Theater"]
minipost = "true"
+++
I'm celebrating a major personal milestone today, and I can't think of a more fitting way to commemorate it on this site than by encouraging you all to watch one of my favorite episodes of The Ray Bradbury Theater from 1989, The Wonderful Death of Dudley Stone. This episode is indeed all about decisions, priorities, and focusing on what's important in life.  

### Part 1
{{< youtube rxUFfxrUh-I >}}

### Part 2
{{< youtube tfAwo3ZMdkI >}}

### Part 3
{{< youtube 15xeGi0X63A >}}
