+++
title = "Who You Really Are"
description = "The wisdom of Elder Joseph"
date = "2019-03-18T12:02:52-05:00"
externalurl = "https://www.youtube.com/watch?v=SDn_BXyCvLk"
categories = ["Journal"]
tags = ["religion", "Orthodoxy"]
+++
{{< youtube SDn_BXyCvLk >}}
