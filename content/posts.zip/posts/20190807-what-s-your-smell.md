+++
categories = ["Journal"]
date = "2019-08-07T01:00:00-05:00"
description = ""
externalurl = "https://www.atlasobscura.com/articles/ann-haviland-fragrances-new-york.amp"
tags = ["news"]
title = "What’s Your Smell?"
+++
I wonder what coffee, grass, and new computer would smell like?
