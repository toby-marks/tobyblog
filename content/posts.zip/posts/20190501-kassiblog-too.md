+++
title = "Kassi Blogs, Too"
description = "My wife has a new blog."
date = "2019-05-01T17:46:58-05:00"
externalurl = "https://kassiblogtoo.blogspot.com/2019/04/the-holy-week-battle-of-martha-v-mary.html"
categories = ["Journal"]
tags = ["Kassi"]
+++
My wife Kassi recently started her own blog of a more private nature, and she's written a wonderful article about all of the many things going on in our lives last week, including our baptism, preparation for Pascha, and the appearance of the first clusters of firewheels in Dallas. Take a look.
