+++
title = "Liturgical Music for Holy Week"
description = ""
date = "2020-04-14T14:05:30-05:00"
categories = ["Music"]
tags = [""]
minipost = "true"
+++
Some of what I've been up to over the past week. This is a recording of the church choir taken after Palm Sunday liturgy. I believe it's meant to be instructional for the other cantors who will be assisting during Holy Week services.

<iframe width="100%" height="300" scrolling="no" frameborder="no" allow="autoplay" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1032079801&color=%23ff5500&auto_play=false&hide_related=false&show_comments=true&show_user=true&show_reposts=false&show_teaser=true&visual=true"></iframe>