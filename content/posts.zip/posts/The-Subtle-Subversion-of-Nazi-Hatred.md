+++
title = "The Subtle Subversion of Hating Nazis"
description = "Hitler is not the devil."
date = "2020-04-28T09:50:49-05:00"
categories = ["News"]
tags = ["nazis", "media"]
externalurl = "https://medium.com/humungus/in-the-future-everyone-will-be-a-nazi-for-15-minutes-aa4ef574ad1b"
+++
> It’s not a contest but every generation has to confront its own evil because there is something deeply wrong with human beings.

The reason for the existence of shows like Hunters is the same reason why [Godwin had to come up with his "Law."](https://simple.wikipedia.org/wiki/Godwin%27s_law) And it doesn't have to do with the laziness of screenwriters, though that does play into it. In the absence of religious faith Hitler and the Nazis *have taken the place of the devil in our collective mythology.* Nazis are inhuman and irredeemably evil bogeymen who we can blame and hate and kill with impunity (at least in our works of fiction). In fact, not to do so would be a moral transgression. The only thing comparable in pop culture would be zombies, but that's another story, and with a different meaning and message.

The great dictatorship in 1984 used scapegoats — individuals in that case — to focus and direct the people's pent-up rage and frustration, *in an effort to control them.* The actual Nazis did the same, but they didn't invent it. They simply knew how to harness it well. It's a phenomenon as old as society and common to all peoples, because people are broken.

When you hate someone, an actual living person or group of people, who you blame for all the problems because of something you read or saw in the media — whether those people are Nazis or "the Jews" or Donald Trump or George Soros — there is a good chance you are being manipulated. 