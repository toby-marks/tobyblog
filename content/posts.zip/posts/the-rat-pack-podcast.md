+++
title = "Community Theater Presents: The Rat Pack"
description = "Sounds from a night out at the theater."
date = "2020-01-30T12:00:00-06:00"
categories = ["Sounds"]
tags = [""]
minipost=true
+++
Recorded on an evening out with [Kass](http://kassiblogtoo.blogspot.com/). Not the best recording, but then again, not the best performance. They tried, though. Sammy and Dean were pretty good, I thought.

{{< soundcloud 750814666 >}}
