+++
title = "A Frank Zappa Halloween Costume"
date = "2018-04-25T17:25:39-05:00"
categories = ["Journal"]
tags = ["music", "Halloween", "Frank Zappa"]
minipost = true
images = ["http://www.zappa.com/sites/g/files/aaj776/f/styles/suzuki_breakpoints_image_desktop-sm_2x_16x9/public/news/201709/Halloween-77_NEWS.jpg"]
+++
I think I just found my Halloween costume for this year.

How did I ever miss this? It debuted just last year for the 40th anniversary celebration of Frank Zappa's [legendary Halloween concert series at The Palladium in New York](https://www.youtube.com/watch?v=DxIYPq0PsCw). Zappa did Halloween concerts throughout the entirety of his career, but the one in 1977 is generally considered to be the apogee of that grand tradition. 

To commemorate that series of shows (which ran from October 28-31), [the family released a massive box set](http://www.zappa.com/news/halloween-77-box-set-celebrates-historic-concert-runs-40th-anniversary-october-20) that includes all six concerts on a USB stick, in 24-bit WAV audio for a flawless sound experience, PLUS a jaw-dropping adult size Frank Zappa costume in vintage 70s plastic style. Worth every penny, and still [available from Walmart for around 80 bucks](https://www.walmart.com/ip/Halloween-77-Limited-Edition/389476830?wmlspartner=wlpa&selectedSellerId=4115&adid=22222222227123273768&wl0=&wl1=g&wl2=c&wl3=234249714372&wl4=pla-385955699003&wl5=9026811&wl6=&wl7=&wl8=&wl9=pla&wl10=115794308&wl11=online&wl12=389476830&wl13=&veh=sem). 

{{< picture src="https://www.zappa.com/files/2017/09/news_201709_Halloween-77_NEWS.jpg" >}}
