+++
date = "2019-03-08T06:00:00+00:00"
title = "Happy Spring!"
categories = ["Journal"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552058843/img/A7324368-1D4C-42A9-B026-2872EE54A5D0.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552058843/img/A7324368-1D4C-42A9-B026-2872EE54A5D0.jpg" >}}

Happy springtime to all you players out there. The weather’s warming up here in Texas. We’re coming out of winter. I think we’re through the worst of it. Are you looking for signs of new growth? Look to the trees! They’re always the first to show. 
