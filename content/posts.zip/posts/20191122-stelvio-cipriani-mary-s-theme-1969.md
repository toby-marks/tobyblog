+++
categories = ["Music"]
date = 2019-11-22T23:50:00Z
description = ""
externalurl = "https://youtu.be/OGQR3Chf9hE"
tags = ["Stelvio Cipriani","easy tempo"]
title = "Stelvio Cipriani — Mary’s Theme (1969)"

+++
{{< youtube OGQR3Chf9hE >}}
