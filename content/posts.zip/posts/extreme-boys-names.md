+++
title = "Slayer, Striker, Shooter and the Rise of the Extreme Baby Boy Name"
description = ""
date = "2020-01-10T15:35:40-06:00"
externalurl = "https://melmagazine.com/en-us/story/extreme-boys-names"
categories = ["News"]
tags = [""]
+++
> In a recent Namerology article on the topic, she lists several of the burlier, more aggressive names that have been picking up steam: Angler, Camper, Tracker, Trapper, Catcher, Driver, Fielder, Racer, Sailor, Striker, Wheeler — deep breath — Breaker, Roper, Trotter, Wrangler — still going — Lancer, Shooter, Slayer, Soldier, Tracer, Trooper — wait, “Slayer”? — Blazer, Brewer, Charger, Dodger, Laker, Pacer, Packer, Raider, Ranger, Steeler, Warrior — kill me — Dreamer, Jester and — wait for it — Rocker.

At first this article gave me a headache, but then I got over and learned to love extreme baby boy names.

So for the record, when I'm picking my baseball team I got dibs on Slugger, Fielder, Racer, and Ump. Sorry, but you get stuck with Dreamer, Jester, Slacker, and Sailor.

So sold on these new baby names am I that I decided to come up with my own list of super jacked-up hot rod names. Feel free to steal any of these that you like.

Biggun Manchester<br>
Ripper Reichskiller<br>
Surge Dominator<br>
Hugh Johnson

P.S. I couldn't help but notice the lack of popular baby names like Coder, Manager, or Commuter. What, no love for the IT life? 
