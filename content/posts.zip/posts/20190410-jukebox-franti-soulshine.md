+++
title = "🎧 Soulshine"
description = "Today's jukebox selection — Soulshine by Michael Franti"
date = "2019-04-10T11:11:56-05:00"
externalurl = "https://www.youtube.com/watch?v=FoI9aGEZpDE"
categories = ["Music"]
tags = ["pop"]
+++
Don't you need it?

{{< youtube FoI9aGEZpDE >}}
