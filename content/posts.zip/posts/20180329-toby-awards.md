+++
title = "The Toby Awards"
date = "2018-03-29T09:47:54-05:00"
categories = ["Journal"]
minipost = true
images = ["https://live.staticflickr.com/901/39497808430_138676a9e6_o.jpg"]
+++
And the Toby for Outstanding Building of the Year goes to… (Cut to rival building management teams dressed up in tuxedos, sitting on the edge of their seats.)

{{< picture alt="The Toby Awards?" src="https://live.staticflickr.com/901/39497808430_138676a9e6_o.jpg" >}}

Makes me wonder what a Toby looks like. Today, too sick to care.
