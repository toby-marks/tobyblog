+++
title = "Physical Challenge Accepted?"
description = ""
date = "2020-05-16T11:07:15-05:00"
categories = ["Stunts"]
tags = ["fitness"]
minipost = "true"
+++
<blockquote class="twitter-tweet"><p lang="en" dir="ltr">🤯 We have NO idea how she did that <a href="https://t.co/K5SbLAnIzk">pic.twitter.com/K5SbLAnIzk</a></p>&mdash; RT Sport (@RTSportNews) <a href="https://twitter.com/RTSportNews/status/1261660423952060417?ref_src=twsrc%5Etfw">May 16, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

And here we go

<a data-flickr-embed="true" href="https://www.flickr.com/photos/tobyjmarks/49901210393/in/photolist-2j2AKjr" title="Getting up from prone position"><img src="https://live.staticflickr.com/31337/49901210393_8979760a9a_o.jpg" width="1920" height="1080" alt="Getting up from prone position"></a><script async src="//embedr.flickr.com/assets/client-code.js" charset="utf-8"></script>
