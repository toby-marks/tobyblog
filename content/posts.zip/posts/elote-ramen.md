+++
title = "Elote Ramen May be the King of Fusion Cuisine"
description = ""
date = "2020-04-14T08:41:18-05:00"
categories = ["Food"]
tags = [""]
externalurl = "https://www.foodbeast.com/news/elote-instant-ramen/?fbclid=IwAR0amuQ_BW29HigFPbpm4FLw-MdGmrRIlHQYf96DSh-fwZjkQJRniQQUMto"
+++
This comes courtesy of good buddy Brian Hammons at [reviewtheworld.com](http://reviewtheworld.com/), now celebrating its 15th year on the internet, I believe. As if I didn't need another reason during this lockdown to get my hands on some Tajin.

I tell you, fans, I could not be *more* ready to reintroduce cheese into my diet.

{{< youtube y_hgv6_rfbg >}}

Haters be silent. Cheese in ramen is a cheap American innovation, granted, but ramen is nothing if not versatile and accommodating. And there is surprisingly nothing wrong with the flavor, either. And it was in [Pasadena]({{< ref "20190419-three-new-pasadena-restaurants.md" >}}), no mean ramen town, that I first discovered corn in ramen, and I was surprised at how well it meshed with the flavor and texture profile of traditional ramen. 

Not to mention that I just flat out love elote. 

Yeah, come next week this is definitely happening.