+++
title = "Tia Lupita is Literal Awesome Sauce"
description = ""
date = "2020-05-04T17:33:01-05:00"
categories = ["Food"]
tags = ["reviews"]
externalurl = "https://www.thrillist.com/eat/nation/best-craft-hot-sauces"
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1588631554/img/crop_jpeg_quality_60_progressive.jpg" >}}

Of the craft sauces listed in the article, I can personally vouch for Tia Lupita (red, not the salsa verde) and pretty much all of the Yellowbird sauces from Austin. The thing that really sets Tia Lupita apart its strong cumin-y flavor, which I happen to love. That stuff is really great on eggs, but honestly goes with almost everything. 