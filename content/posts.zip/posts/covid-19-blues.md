+++
title = "The Covid-19 Blues"
description = ""
date = "2020-03-28T10:40:30-05:00"
categories = ["Music"]
tags = ["coronavirus","covid19"]
externalurl = "https://www.youtube.com/watch?v=gyANd89_c0g"
+++
Just got this from my brother, who at this moment is being hospitalized in Louisiana for pneumonia and possible coronavirus infection. Still awaiting results of his 2nd test. Hasn't killed his sense of humor. We love you, Josh. Get well.

{{< youtube gyANd89_c0g >}}