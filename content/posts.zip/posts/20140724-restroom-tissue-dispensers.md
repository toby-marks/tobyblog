+++
title = "Restroom Tissue Dispensers"
date = 2014-07-24T22:15:00Z
categories = ["Reviews"]
images = ["https://lh3.googleusercontent.com/-54e0eSjh9S8/U9FwlwwqJqI/AAAAAAAAAkA/WBmtk8iqmGc/s640/blogger-image--541685519.jpg"]
+++
(Works best if you read this in an Andy Rooney-esque whine.)

This keeps happening to me over and over and over again lately. I have to make use of the public facilities (seldom a delightful experience anyway), I go to the sink, wash my hands, look up, and see this mess —

{{< picture alt="" src="https://lh3.googleusercontent.com/-54e0eSjh9S8/U9FwlwwqJqI/AAAAAAAAAkA/WBmtk8iqmGc/s640/blogger-image--541685519.jpg" >}}

Now what is wrong with this picture? Take a look at how this works.

<!--more-->

{{< picture alt="" src="https://lh4.googleusercontent.com/-JCOUiFmIvJk/U9Fw4TbxbOI/AAAAAAAAAkQ/NDn5bZH8FqQ/s640/blogger-image--1827737721.jpg" >}}

You're supposed to pull the sheets from the bottom, and the angular momentum of your pull dispenses the next sheet. But what if there's no sheet? Huh? What then?!

{{< picture alt="" src="https://lh3.googleusercontent.com/-zkDqWVsBa4I/U9Fw7G1hklI/AAAAAAAAAkY/CzPWP4RKGI8/s640/blogger-image-1156149362.jpg" >}}

There's clearly paper in there, but somebody ripped the damn thing off right at the source! And on models like these, there is no lever to force a tissue feed. You know how hard it is to coax that sheet out given the few millimeters of purchase visible in the above pic?

Nigh impossible.

But yet, somehow I'ved managed it. Every. Single. Time.

{{< picture alt="" src="https://lh6.googleusercontent.com/-OlpkWym9YsQ/U9FwzsNaeDI/AAAAAAAAAkI/lmJBKipsY0A/s640/blogger-image-1237055518.jpg" >}}

Are people too anal to leave a sheet hanging from the dispenser? Because you really have to try hard to tear it off right at the top. I can tell you that this is how it's supposed to look when you leave the restroom, for the convenience the folks who come in after you.

That's about it.

This has been a public service message of sorts. Thanks for your attention. Now would be a great time to subscribe if you want to get up-to-the-minute updates and features like the one you're reading now. Don't miss out!
