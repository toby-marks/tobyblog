+++
title = "Unbelievable: Real or Bullshit? Question Supercut"
description = ""
date = "2020-03-16T12:23:27-05:00"
categories = ["FoundFootage"]
tags = ["youtube"]
micropost = true
externalurl = "https://www.youtube.com/watch?time_continue=47&v=9S1EzkRpelY&feature=emb_logo"
+++
Answer these questions in the comments, then forward this blog to 10 of your friends (assuming you have 10 friends).

{{< youtube 9S1EzkRpelY >}}