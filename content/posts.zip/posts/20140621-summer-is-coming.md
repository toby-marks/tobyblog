+++
title = "Summer is Coming"
date = 2014-06-21T08:52:00Z
categories = ["Journal"]
minipost = "true"
images = ["http://1.bp.blogspot.com/-jX8INn66ESE/U6Wp9MBW79I/AAAAAAAAAfg/y5WbLf8xnFs/s2048/DSC04353.jpg"]
+++
{{< picture alt="" src="http://1.bp.blogspot.com/-jX8INn66ESE/U6Wp9MBW79I/AAAAAAAAAfg/y5WbLf8xnFs/s2048/DSC04353.jpg" >}}

In fact, it's already here. My woodland trekking has been sidelined a bit due to having to nurse a sumac rash, but I'll be back soon enough. Here's hoping you guys get out and sweat a bit this summer. Enjoy the late evenings while you can! DST. What a gift from Mr. Nixon!
