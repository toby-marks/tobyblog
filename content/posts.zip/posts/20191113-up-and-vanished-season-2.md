+++
title = "Listening: Up and Vanished, Season 2"
description = ""
date = "2019-11-13T16:07:43-06:00"
categories = ["Podcasts"]
tags = ["murder"]
minipost=true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1573682807/img/Screen_Shot_2019-11-13_at_4.05.48_PM.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1573682807/img/Screen_Shot_2019-11-13_at_4.05.48_PM.jpg" >}}

An investigation into the disappearance of Kristal Reisinger from Crestone, Colorado. 

[Go to the main site](https://season2.upandvanished.com), or [listen on Apple Podcasts.](https://podcasts.apple.com/us/podcast/up-and-vanished/id1140596919)

I was unimpressed by season one, which made host Payne Lindsey podcast-famous for cracking the notoriously cold case. This one is better. And it's set in Colorado, which has some appeal to me. You can always tell people from there. They're windblown, so to speak. 

Check it out, if you like a mystery. It's not a very happy story about not a very happy life, but perhaps as in the first season it will bring some justice and relief. There are bits and pieces of information presented that might be relevant to the Missing 411 phenomenon. 
