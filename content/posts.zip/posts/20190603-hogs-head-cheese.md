+++
title = "Hogs Head Cheese: A Disappearing Delicacy"
description = ""
date = "2019-06-03T09:28:36-05:00"
externalurl = "https://www.atlasobscura.com/foods/louisiana-hogs-head-cheese"
categories = ["Journal"]
tags = ["news","food"]
+++
I can't claim that I was one who helped to postpone the extinction. Somebody told me once as a kid that it contained pig's brains, so I never ate it. It pretty much looked like jello'd meat, too, which didn't add to the appeal. I'd try it today, though, if I still lived there, and probably would like it. Vinegar and pork is not a bad combo.
