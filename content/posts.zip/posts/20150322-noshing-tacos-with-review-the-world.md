+++
title = "Noshing Tacos with Review the World"
date = 2015-03-22T08:04:00Z
categories = ["Journal"]
tags = ["Brian Hammons","reviewtheworld.com"]
minipost = "true"
images = ["http://4.bp.blogspot.com/-_jNkX_Wn1RU/VQ7ZBI5M3kI/AAAAAAAABwM/vUXpRNftTvU/s2048/IMG_1240.JPG"]
+++
{{< picture alt="" src="http://4.bp.blogspot.com/-_jNkX_Wn1RU/VQ7ZBI5M3kI/AAAAAAAABwM/vUXpRNftTvU/s2048/IMG_1240.JPG" >}}

Once again we were proud to host buddy Brian Hammons of the food/candy/retro/life blog Review the World as he made his way down to Dallas for the big UFC 185 fight night. What a weekend! Among other things, I introduced Brian Hammons to some of the best tacos in the COUNTRY. Go see what resulted over on [reviewtheworld.com.](http://www.reviewtheworld.com/2015/03/texas-taco-challenge-taco-naan-vs-fuel.html)
