+++
title = "Jim Carrey in The Shining"
description = ""
date = "2020-04-28T13:41:27-05:00"
categories = ["News"]
tags = ["horror"]
externalurl = "https://www.youtube.com/watch?v=3Fz9ZxZcMVY"
+++
Deepfake. I would have preferred this use his Ace Ventura voice, but I guess the AI isn't up to that (yet).

{{< youtube 3Fz9ZxZcMVY >}}
