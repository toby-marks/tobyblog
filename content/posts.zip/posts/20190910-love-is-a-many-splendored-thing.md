+++
title = "Love Is a Many Splendored Thing"
description = ""
date = "2019-09-10T12:49:17-05:00"
categories = ["Music","Journal"]
tags = [""]
minipost = true
+++
One of my earliest memories is asking my mom to borrow an old Hallmark music box that played this song. It was important to me, though I couldn't explain why. I'd listen to it over and over again, long past the point of annoyance to everyone. Sometimes at night, when I was scared, I'd listen to it to help me sleep. It has a sad, but sweet melody. At about 2:00 it has the proper timing, then very quickly starts to unwind. It becomes sort of haunting, which is most likely why I remember it. It was lost for many years. I have some memory of finding it once in my early teen years. I took it apart, played some with the mechanism, then lost it again. Who knows where those things go when they're gone. I suppose it's rotting in some garbage pile now, but there's a possibility it may be buried in our old yard. 

{{< youtube 66Es33FV9-E >}}
