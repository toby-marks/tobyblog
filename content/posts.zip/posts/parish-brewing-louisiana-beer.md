+++
title = "Parish Brewing"
description = ""
date = "2020-01-17T15:13:21-06:00"
externalurl = "http://www.parishbeer.com/"
categories = ["Reviews"]
tags = [""]
+++
[{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1579295570/img/Screen_Shot_2020-01-17_at_3.12.01_PM.jpg" >}}](http://www.parishbeer.com/parish-beer)

Looks to me like South Louisiana microbrews are coming of age. I think the time has come to get my hand on a few of these.
