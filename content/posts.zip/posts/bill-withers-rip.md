+++
title = "RIP — Bill Withers 💀"
description = ""
date = "2020-04-03T16:13:07-05:00"
categories = ["Music"]
tags = [""]
externalurl = "https://www.youtube.com/watch?v=bEeaS6fuUoA"
+++
I found out Bill Withers died today. Not a huge fan, but I am rather fond of this one of his.

{{< youtube bEeaS6fuUoA >}}

I used that song in the intro to one of my old videos, one I did with Augie back in my personal [golden age of geocaching.]({{< relref "/videos/march-cache-maintenance.md" >}}) 

I miss those days.
