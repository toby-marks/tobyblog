+++
title = "A History of the Puffy Toilet Seat"
description = ""
date = "2019-08-15T11:16:30-05:00"
externalurl = "https://www.dollarshaveclub.com/content/story/a-not-quite-complete-history-of-the-puffy-toilet-seat"
categories = ["Journal"]
tags = ["news"]
+++
I always considered those things the grossest of the gross. But did get me thinking about alternative "comfortable" materials. A gel toilet seat? Cushion of air? Water? Yeah, like a water bed — but instead it's a toilet seat.

And if you don't already follow the [bro-science blog](https://www.dollarshaveclub.com/content/) of [Dollar Shave Club](https://www.dollarshaveclub.com/), you should. Way better than [The Onion](http://theonion.com/) these days.
