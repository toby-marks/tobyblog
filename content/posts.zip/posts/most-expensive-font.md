+++
title = "The Most Expensive Font in the World"
description = ""
date = "2020-04-03T16:00:36-05:00"
categories = ["News"]
tags = ["fonts"]
externalurl = "https://medium.com/@msilvertant/the-most-expensive-typefaces-in-the-world-d025923084f0"
+++
It's because it takes a lot of powerful tech to bend that slant backwards.
