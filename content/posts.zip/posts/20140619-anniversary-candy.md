+++
title = "Anniversary Candy"
date = 2014-06-19T22:27:00Z
categories = ["Reviews"]
tags = ["food"]
images = ["https://lh3.googleusercontent.com/-xm0JFA17S_I/U6R9zcsBA4I/AAAAAAAAAew/h2zWFMTegHk/s640/blogger-image--2114821383.jpg"]
+++
{{< picture src="https://lh3.googleusercontent.com/-xm0JFA17S_I/U6R9zcsBA4I/AAAAAAAAAew/h2zWFMTegHk/s640/blogger-image--2114821383.jpg" >}}

Aren't I lucky? How many guys get to have a truly one of a kind candy made just for them?

<!--more-->

What you are looking at is an out of this world treat that I have dubbed "Anniversary Candy". Made by my wife, purely for my own enjoyment.

{{< picture src="https://lh3.googleusercontent.com/-hPxrAh8memc/U6R91SC1_lI/AAAAAAAAAfA/Iqa17GbLaDg/s640/blogger-image-1267678754.jpg" >}}

She made the first batch a few years ago for Christmas, and it's been a special request of mine ever since on celebratory occasions.

{{< picture src="https://lh4.googleusercontent.com/-fkJ8sU1c7tk/U6R90Xz-xJI/AAAAAAAAAe4/aqiaX2DXaYM/s640/blogger-image-1988080906.jpg" >}}

This batch was made with almond butter, pecans, cashews, macadamia nuts, honey, and chocolate. There's a little sprinkling of Kosher salt on top for a flavor kick.

I've always thought we could sell this stuff and make millions. I contemplate that sometimes, when I pull another candy shard out of the freezer. I'm a very rich man.

