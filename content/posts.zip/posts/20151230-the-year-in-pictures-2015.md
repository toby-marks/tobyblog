+++
draft = "true"
title = "The Year in Pictures — 2015 Edition"
description = ""
date = "2015-12-30T15:27:46-06:00"
categories = ["Journal"]
images = ["https://live.staticflickr.com/5706/23706289739_3ca2619b2a_k.jpg"]
minipost = "true"
+++
[{{< picture alt="" src="https://live.staticflickr.com/5706/23706289739_3ca2619b2a_k.jpg" >}}](https://www.flickr.com/photos/tobyjmarks/sets/72157662813734772/)

*You have unlocked secret bonus content!*

Welcome to this retroactively inserted yearly retrospective. The date I am writing this is actually December 30, 2020. If you've found this page, that means you've stumbled upon some content that, while genuinely old, was not originally posted on this date. Greetings from the future! Or something. I suppose I could make some joke right now warning you to "turn back" from the dread year 2020, but that whole bit seems tired and depressing.

Instead I will invite you to look at this gallery of my favorite photos from 2015; a year that included a fantastic visit from my buddy [Brian](http://reviewtheworld.com/) from Ohio, a really glorious crop of firewheels (the likes of which we've not seen since), and one of my greatest sets of Halloween carved pumpkins ever — a tribute to the Universal Monsters. 

Enjoy!
