+++
title = "Working From Malls"
description = ""
date = "2019-08-23T11:11:46-05:00"
categories = ["Journal"]
tags = ["work"]
minipost = true
+++
I love working from shopping malls. I was just telling Kassi the other day that they offer several advantages that suit me and my work style well. Doors open early. Easy access to restrooms. Most have at least some access to power; and free wifi, though I always tether. The ambient noise is generally at an appropriate level, though my current environment has somewhat more than the usual. More than anything I appreciate the large, wide open spaces and natural light that filters in through the ceiling glass. There's something about that mix that enhances creativity, I think. Focuses attention. Did I mention coffee? Always access to coffee. And room, I suppose, to walk around on a short break at lunch, and interesting things to look at.
