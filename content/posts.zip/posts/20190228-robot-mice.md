+++
title = "My Love, She Weeps At Many Things"
description = "A poem by Ray Bradbury"
date = "2019-02-28T01:41:02-06:00"
categories = ["Books"]
tags = ["Ray Bradbury"]
minipost = "true"
images = ["https://live.staticflickr.com/7896/46298054945_7fc2b02e2f_k.jpg"]
+++
{{< picture alt="Nightstand" src="https://live.staticflickr.com/7896/46298054945_7fc2b02e2f_k.jpg" >}}

My love, she weeps at many things,<br>
I would not for the world stop up her tears;<br>
She came in many years of drought<br>
And taught me just how right was private rain<br>
To touch the dust with smallest storm <br>
With emerald droppings from her eyes.<br>
<!--more-->
My loved one weeps at many things,<br>
Small rings and charms, the soft alarms of birds,<br>
Or sudden summer squall. Large thing or small:<br>
The way the cat puts up his bones in fur,<br>
Teakettle purrs and murmurs:<br>
Slumber. Sleep. October. Autumn. Fall.<br>
Sometimes I say a thing and do not know I say a Joy<br>
Then hear a sound and turn and there she goes full-weep.<br>
Pours forth the diamonds, lets out a cry<br>
As from a thousand hours of happy nightmare/sleep.<br>

In all the splendid time ahead, those years<br>
With yet their secret joys unsaid,<br>
Let no one stay her tears.<br>
Praise God for them and her, praise God for eyes<br>
That smallness see, and grow it to a size,<br>
That see in me a fellow weeper found<br>
And celebrate by laying dust<br>
On our small ceremonial trysting ground.<br>
Then am I rich?<br>
Look here… I wear with grace<br>
The gifts of rain and light and love and time<br>
She's made and winked and left<br>
To brighten my soul's face.<br>
