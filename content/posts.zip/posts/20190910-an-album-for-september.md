+++
categories = ["Music"]
date = "2019-09-10T21:00:00-05:00"
description = ""
minipost = "True"
tags = ["Frank Sinatra","pop"]
title = "An Album for September"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1568167440/img/58D5973D-30AF-4712-9C35-3CA17A02468A_hzezqg.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1568167440/img/58D5973D-30AF-4712-9C35-3CA17A02468A_hzezqg.jpg" >}}

Doing chores, having a 🥃  while I listen to Frank’s album about growing old. 
