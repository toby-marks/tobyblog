+++
title = "Spirit Halloween Store Opening Soon"
date = 2014-08-02T11:06:00Z
categories = ["Journal"]
tags = ["Halloween","Augie"]
minipost = "true"
images = ["https://lh5.googleusercontent.com/-MWHOMxI05LI/U90onQmy-wI/AAAAAAAAAuI/1DAA21qjDXA/s640/blogger-image--108744692.jpg"]
+++
{{< picture alt="" src="https://lh5.googleusercontent.com/-MWHOMxI05LI/U90onQmy-wI/AAAAAAAAAuI/1DAA21qjDXA/s640/blogger-image--108744692.jpg" >}}

Took a little stroll through the neighborhood this morning, and what should we find?

Come September, tune in to Tobyblog for further details!
