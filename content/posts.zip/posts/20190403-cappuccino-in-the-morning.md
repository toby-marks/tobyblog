+++
date = "2019-04-03T09:00:00+00:00"
title = "Cappuccino in the Morning "
categories = ["Journal"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1554304247/img/063BF195-AF64-4498-BD1A-37F5F61BCD99.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1554304247/img/063BF195-AF64-4498-BD1A-37F5F61BCD99.jpg" >}}

A cappuccino is a wonderful way to start the morning. Though this morning I can say I’ve had better. There was a guy here who had one of those ironic mustaches. He could make good coffee. I wonder where he went. And if he still has that mustache. And if he left, maybe, to startup some better place that specializes in morning cappuccinos? And where that place might be, and if they have WiFi?

Good morning. 🌞 
