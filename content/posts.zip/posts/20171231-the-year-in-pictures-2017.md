+++
title = "The Year in Pictures — 2017 Edition"
description = "Some of my favorites photos from 2017"
date = "2017-12-31"
categories = ["Journal"]
minipost = "true"
images = ["/img/2017-12-31-top-nine/top9.jpg"]
+++
{{< picture src="images/2017-12-31-top-nine/top9.jpg" >}}

Some of my favorite pictures from the past year. [See the full set on Flickr.](https://www.flickr.com/photos/75738497@N00/sets/72157688929748362)
