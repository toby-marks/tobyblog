+++
title = "The Cleverest Life Hack"
description = ""
date = "2020-01-16T11:02:11-06:00"
externalurl = "https://medium.com/@Chef_BoyarDEJI/the-most-clever-life-hack-ive-ever-learned-4648e5631b51"
categories = ["News"]
tags = ["lifehacks"]
+++
Wait, just hear me out on this…

