+++
title = "Neighborhood Noise"
description = ""
date = "2020-07-28T13:19:32-05:00"
categories = ["Sounds"]
tags = [""]
minipost = "true"
+++
Come along with me on one of my daily quarantine walks, from the moment I step out my front door to my daily visit to the neighborhood Pokéstop; around the back side of the  neighborhood past the park and near the woods, then along the road past the gun range to the creek overlook and back. 

{{< soundcloud 865674388 >}}
