+++
date = "2019-04-07T00:00:00+00:00"
title = "Spring buds"
categories = ["Journal"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1554611133/img/E9DB253A-CCFB-44AF-9FF5-F117E08843D5.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1554611133/img/E9DB253A-CCFB-44AF-9FF5-F117E08843D5.jpg" >}}

All winter keep still.<br>
Naked, silent. Dream until<br>
spring ends cold’s vigil.
