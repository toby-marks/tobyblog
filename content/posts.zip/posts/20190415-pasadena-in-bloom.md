+++
categories = ["Journal"]
date = "2019-04-15T10:00:00+00:00"
description = ""
minipost = true
tags = ["Pasadena","California","travel"]
title = "Pasadena in Bloom"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1555472121/img/F4CD0640-9C65-4593-8E91-57F76A2DF752.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1555472121/img/F4CD0640-9C65-4593-8E91-57F76A2DF752.jpg" >}}

The streets of Old Town Pasadena are lined this April in pink and purple blooms. A little natural spring beauty. Something of a birthday treat from God.
