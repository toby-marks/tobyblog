+++
title = "A West Coast Hike from Mexico to Canada"
description = ""
date = "2020-05-15T15:06:36-05:00"
categories = ["Travel"]
tags = [""]
externalurl = "https://youtu.be/styiDn7YKhE"
+++
I try to get out for a walk every day. I think it's done a great deal to help maintain peace of mind, a sense of time, and a connection with my local environment. Sometimes, though, I'd like to venture a little further abroad and take in more than just the local sights. I've never had opportunity to do any *really* serious hiking like this. I wonder how long it would take to train for a five-month hike. And what would it be like to be able to totally dedicate that amount of time to an experience like that?

Anyhoo, here's the highlights in three minutes. Man, do my legs feel sore after watching that. 

Time for a beer. 🍺

{{< youtube styiDn7YKhE >}}