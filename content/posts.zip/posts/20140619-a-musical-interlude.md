+++
title = "A Musical Interlude"
date = 2014-06-19T22:34:00Z
categories = ["Music"]
tags = ["folk"]
minipost = "true"
+++
{{< youtube 5HKAuaU5VlE >}}