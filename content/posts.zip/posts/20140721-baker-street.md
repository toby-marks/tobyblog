+++
title = "Baker Street"
date = 2014-07-21T14:05:00Z
categories = ["Music"]
tags = ["pop music"]
minipost = "true"
+++
Love this song. Local musician Bruce Wilder was recently performing it solo at Firewheel Coffee, my office away from the office. Makes me want to sneak up behind him with a giant saxophone and start blaring away at the appropriate moments.  

{{< youtube 3HMH3jsDfT0 >}}