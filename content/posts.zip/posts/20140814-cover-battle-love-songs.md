+++
title = "Cover Battle — Love Songs"
date = 2014-08-14
categories = ["Music"]
tags = ["pop music"]
+++
It's time once again for one of my patented YouTube cover battles, and in typical fashion you pick the winner. Tonight's theme is one of my favorite for YouTube covers — LOVE SONGS. I have my personal favorite, of course, but I won't spoil it for you. Enjoy, and leave a comment to vote for the winner. 

<!--more-->

The first track is by [Goga](http://www.gogamusic.com), a local (Dallas) wedding singer and one-man-band act. This was actually filmed at a performance in downtown Dallas in 2008. Go Goga! 

{{< youtube k9sQJOC2sxA >}}

Next up is YouTube artist [Rob Preston](https://www.youtube.com/user/RPreston01/featured) singing Billy Joel's Just The Way You Are. Barry White did do a nice cover of this song, but I still prefer Joel's version. But Preston's cover is not bad, and songs seem more soulful when sung alone in your office/living room. 

{{< youtube fWF5OySj2WA >}} 

Last we have professional musician [Jude Perl](https://www.judeperl.com) singing an offbeat rendition of Marvin Gaye's classic. A good attempt at a viral hit? You be the judge. 

{{< youtube 3UVcxHh-0e4 >}}
