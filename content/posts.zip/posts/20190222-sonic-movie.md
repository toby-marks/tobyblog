+++
title = "What the Hell is This Poster For the Sonic the Hedgehog Movie?"
date = "2019-02-21T22:27:13-08:00"
categories = ["Journal"]
tags = ["gaming","movies"]
minipost = true
images = ["/img/sonic_movie.jpg"]
+++
The Sonic the Hedgehog movie comes out this year. 

*Are you hyped, nostalgia boys?!* 

Because if you look at this poster and get hyped, I'm calling the cops. Seriously, who designed this freakish movie poster and why is he/she not in jail/hell?

{{< picture alt="Augie poses in front of the somewhat perverted poster for the Sonic the Hedgehog movie" src="images/sonic_movie.jpg" >}}
