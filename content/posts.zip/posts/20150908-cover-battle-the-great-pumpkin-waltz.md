+++
title = "Cover Battle — The Great Pumpkin Waltz"
date = 2015-09-08T11:10:00Z
categories = ["Music"]
tags = ["Halloween"]
+++

We are officially in the "-BER months" now, a time of year that for my generation is indelibly stamped by the melancholy Peanuts cartoon soundtracks of Vince Guiraldi and his trio. Though the nostalgic quality of these tracks reaches fever pitch around Christmastime, we begin our seasonal contemplation with this wistful little tune, quickly supplanted in the Guiraldi lineup, but never quite forgotten. It remains one of my favorites, but I'll only listen to it from the start of September through Halloween.

<!--more-->

I am partial to [YouTube]({{< ref "20140724-cover-battle--red-rubber-ball.md" >}}) [covers]({{< ref "20140814-cover-battle-love-songs.md" >}}), so here are some covers of The Great Pumpkin Waltz by The Vince Guiraldi Trio. I'm breaking precedent here by allowing in some truly exceptional professional covers simply because I love the piece so much, and those are the ones I use in my personal playlist.

Enjoy. Show these guys some support by liking and/or subscribing to their stuff. And let me know which is your favorite!

{{< youtube pDx0TaySyPw >}}

{{< youtube zvofs4VDZ1U >}}

{{< youtube 8FY-D_um9pE >}}

{{< youtube Bf8ybhao23w >}}

{{< youtube OIo1jubpSmk >}}

{{< youtube sqnrLJu4uew >}}

{{< youtube K3QJSUZ2BHE >}}

{{< youtube vN9E3-e9be0 >}}

{{< youtube MAUW3uLKa88 >}}

{{< youtube 5BaW4BedXoE >}}

{{< youtube 20RkSotA8sg >}}

{{< picture alt="" src="http://2.bp.blogspot.com/-3PtiI6xegg4/Ve8kc-vbvGI/AAAAAAAACZ0/plak79_-DLk/s2048/Unknown.jpeg" >}}
