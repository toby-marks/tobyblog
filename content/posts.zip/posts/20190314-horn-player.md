+++
date = "2019-03-14T12:06:00+00:00"
title = "Horn Player"
categories = ["Journal"]
tags = ["travel","Pasadena","California"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552602904/img/25A20639-6AB5-428E-B013-951140B9B004.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552602904/img/25A20639-6AB5-428E-B013-951140B9B004.jpg" >}}

A street musician doing his thing in Old Town Pasadena.
