+++
title = "First Halloween Merch of the Year"
date = 2014-07-12T06:52:00Z
categories = ["Journal"]
tags = ["Halloween"]
images = ["https://lh5.googleusercontent.com/-EarOXcizEuM/U8E9eAw3IlI/AAAAAAAAAgk/24_MmhFTaq8/s640/blogger-image--1728556188.jpg"]
+++
{{< picture alt="" src="https://lh5.googleusercontent.com/-EarOXcizEuM/U8E9eAw3IlI/AAAAAAAAAgk/24_MmhFTaq8/s640/blogger-image--1728556188.jpg" >}}

Technically spotted on July 1 at Michaels. Thanks to [Swagger Mom](http://swaggermomtales.blogspot.com/) for the tip-off about fall going up this week. That made me wonder, and my suspicions checked out.

<!--more-->

{{< picture alt="" src="https://lh6.googleusercontent.com/-Il8U3Qi8YT0/U8E9iS6zfDI/AAAAAAAAAhE/wxrpVjrJFHc/s640/blogger-image-1441703065.jpg" >}}

And yeah, it was mostly generic fall decorations on a couple of shelves, but over on the other side of the store, on a lonely end cap display, there was this:

{{< picture alt="" src="https://lh4.googleusercontent.com/-E2fPmzojoEw/U8E9fbD1nQI/AAAAAAAAAgs/QTDR6DU49SQ/s640/blogger-image--1965382222.jpg" >}}

Unmistakable. Halloween ribbon.

{{< picture alt="" src="https://lh3.googleusercontent.com/-IDfPnfIMiDA/U8E9gOTFI0I/AAAAAAAAAg0/ShfDayZA8qQ/s640/blogger-image--726152121.jpg" >}}

{{< picture alt="" src="https://lh4.googleusercontent.com/-Foplvr_I5m4/U8E9hU3FzqI/AAAAAAAAAg8/zc0SbMTH7qs/s640/blogger-image--885813066.jpg" >}}

{{< picture alt="" src="https://lh4.googleusercontent.com/-HoWRvztvY1E/U8E9dKtOHLI/AAAAAAAAAgc/8rXxXPzmXFI/s640/blogger-image-1347516825.jpg" >}}

Frankensteins, witches, spiders, skeletons… Have you ever stopped to think how rich Halloween is in iconography?

No, the countdown does not begin here on Tobyblog for quite some time to come, but I can hardly fail to take note of this stuff when I see it.

For now, it's summertime!

