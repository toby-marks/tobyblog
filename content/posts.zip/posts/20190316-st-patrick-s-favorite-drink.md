+++
date = "2019-03-16T17:00:00+00:00"
title = "St. Patrick’s Favorite Drink"
categories = ["Journal"]
tags = ["alcohol"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552775123/img/16C2DDF5-D90F-4B00-ACBB-97AFD0C073C8.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552775123/img/16C2DDF5-D90F-4B00-ACBB-97AFD0C073C8.jpg" >}}

Celebrating St. Patrick’s Day with a couple of Vodka Stingers. Kassi approves. 🍀
