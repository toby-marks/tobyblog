+++
title = "New Orleans Food Review"
date = 2014-07-23T07:35:00Z
categories = ["Reviews"]
tags = ["food"]
images = ["https://lh3.googleusercontent.com/-rHaibYXANIw/U8_Hy4ggYiI/AAAAAAAAAio/oW6JSP1QZeQ/s640/blogger-image-1201992581.jpg"]
+++
{{< picture alt="" src="https://lh3.googleusercontent.com/-rHaibYXANIw/U8_Hy4ggYiI/AAAAAAAAAio/oW6JSP1QZeQ/s640/blogger-image-1201992581.jpg" >}}

New Orleans is, of course, a city known for its food, home to some of the best chefs in the country. I was in town recently, so I figured I'd check out some of the local establishments and give you guys a virtual sight-tasting tour. Let's start with the hotel vending machine.

<!--more-->

Hey, I hadn't eaten all day and I had a couple of hours to kill till my family showed up. This looked like it'd fill a hole. Besides, I hadn't tried these before, and they reminded me of those little cinnamon twists you get at Taco Bell.

{{< picture alt="" src="https://lh3.googleusercontent.com/-kAqmWLv7-og/U8_ICzlgsxI/AAAAAAAAAiw/ajQAmg-Mog0/s640/blogger-image--134749434.jpg" >}}

This was a pretty fresh-tasting bag. It wasn't really as sweet as I was expecting for Honey BBQ, but tasted all right. Tasted a lot like regular Doritos, as a matter of fact, with a slight BBQ flavor.

{{< picture alt="" src="https://lh4.googleusercontent.com/-bAKjb8Ii_ss/U8_Hu6MpdnI/AAAAAAAAAig/Z9YTXv4-DKo/s640/blogger-image--2139266990.jpg" >}}

The twists weren't as delicate as the Taco Bell variety, but much more so than Fritos corn chips. Did I mention these tasted like Doritos? Cause that's pretty much exactly what they tasted like.

{{< picture alt="" src="https://lh3.googleusercontent.com/-2QSCFnKNAmg/U8_IF9JAzMI/AAAAAAAAAi4/XY5b6AB6YHw/s640/blogger-image-281714775.jpg" >}}

It also pairs well with chocolate, if you're really hungry. I assume it'd go nicely with a Sprite, but I wasn't about to pay two bucks for a soft drink. When did vending machines get so expensive?

**VERDICT:** Try it.
