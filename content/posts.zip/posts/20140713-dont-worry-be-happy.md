+++
draft = "true"
title = "Don't Worry, Be Happy"
date = 2014-07-13T16:06:00Z
categories = ["Journal"]
tags = ["food","Anthony"]
minipost = "true"
images = ["https://lh4.googleusercontent.com/-qkQCvBU6dZI/U8MQ5OZQhvI/AAAAAAAAAhU/sK4AWdvfQ2g/s640/blogger-image--1072667005.jpg"]
+++
{{< picture alt="" src="https://lh4.googleusercontent.com/-qkQCvBU6dZI/U8MQ5OZQhvI/AAAAAAAAAhU/sK4AWdvfQ2g/s640/blogger-image--1072667005.jpg" >}}

And that would make him the first of our kids to eat a Happy Meal.

{{< picture alt="" src="https://lh6.googleusercontent.com/-pWn1fHJlr5E/U8MQ8nw0o1I/AAAAAAAAAhc/zDRrtTLJH24/s640/blogger-image-1260906511.jpg" >}}

Not sure if I like the new mascot. He tried to eat the baby's noony.
