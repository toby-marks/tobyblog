+++
title = "Rim a Bloody Mary with Tajin?"
description = ""
date = "2020-04-13T16:30:11-05:00"
categories = ["Food"]
tags = [""]
externalurl = "https://www.thrillist.com/eat/nation/what-is-tajin-mexican-seasoning"
+++
Man, I can't wait till we can have some real Tex-Mex food again. And drink. 😞