+++
title = "Garth Alper — Stratus"
description = ""
date = "2020-09-04T18:15:28-05:00"
categories = ["Music"]
tags = ["YouTube", "Garth Alper"]
externalurl = "https://www.youtube.com/watch?v=RV8UZqrxKUk&list=OLAK5uy_kCYlZ7z4OnIcdxNy9eMLTZuU3My3Gugt8"
+++
This is the guy that taught me and Kass to appreciate jazz, **literally**. He was our old jazz and music appreciation professor in college. On a couple of occasions we went to see him and his band play around town. Neat guy, and some people said we kind of resembled each other.

I always found this sound makes for good study music. This is his third album, I believe, and it's pretty strong. Better than the last one.

<iframe width="100%" height="400px" src="https://www.youtube.com/embed/videoseries?list=OLAK5uy_kCYlZ7z4OnIcdxNy9eMLTZuU3My3Gugt8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
