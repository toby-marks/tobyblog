+++
title = "An All New 👨🏻‍💻 Tobybase.com"
description = "Major site update for Tobybase.com"
date = "2019-04-24T16:18:33-05:00"
categories = ["Journal"]
tags = ["tobybase.com"]
externalurl = "http://tobybase.com"
+++
I've been working on a site overhaul for my pro blog, [Tobybase.com](http://tobybase.com). Go check it out and tell me what you think! Now just need some new content…