+++
draft = "true"
title = "The Year in Pictures"
date = 2014-12-27T21:48:00Z
categories = ["Journal"]
images = ["http://2.bp.blogspot.com/-6i_mWar8nO8/VJ-XS4Eo4uI/AAAAAAAABrg/2YSt64UKmV4/s2048/DSC09211.jpg"]
minipost = "true"
+++
[{{< picture alt="" src="http://2.bp.blogspot.com/-6i_mWar8nO8/VJ-XS4Eo4uI/AAAAAAAABrg/2YSt64UKmV4/s2048/DSC09211.jpg" >}}](https://www.flickr.com/photos/tobyjmarks/sets/72157649926955132/)

Being a fan of post-Christmas year end wrap-ups, I decided to create [a Flickr set](https://www.flickr.com/photos/tobyjmarks/sets/72157649926955132/) highlighting some of the events and activities that filled our lives this year. These are not my best photos or even my favorites, but just a (largish) collection of pictures that capture the essence of 2014 for me. A little bit of countryside, a little bit of life at home. One or two guest appearances. Flowers and ponies and monsters and toys. That kind of thing.
