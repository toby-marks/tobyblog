+++
title = "Isolate The Right Way in a Treehouse Hotel"
description = ""
date = "2020-03-24T09:34:35-05:00"
categories = ["News"]
tags = [""]
externalurl = "https://www.thrillist.com/travel/nation/best-treehouse-hotels"
+++
If you're not waiting out the apocalypse in a treehouse hotel, you're not doing it right. Most of these are in exotic spots around the world, but there happens to be one nearby in Eureka Springs! And very affordable, too.

[{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1585060628/img/tmg-gift_guide_default_2x.jpg" >}}](https://www.thrillist.com/travel/nation/best-treehouse-hotels)
