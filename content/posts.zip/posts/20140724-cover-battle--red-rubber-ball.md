+++
title = "Cover Battle — Red Rubber Ball"
description = "Another YouTube Cover Battle!, a copyrighted feature of Tobyblog.com"
date = 2014-07-24T21:58:00Z
categories = ["Music"]
tags = ["pop music"]
+++
I woke up this morning with this song stuck in my head, thinking about my dad and the good progress he's making recovering from a triple bypass operation.

<!--more-->

I probably thought of it because I noticed it was in the repertoire of local musician Bruce Wilder, who graced us at the coffee shop one evening with his guitar.

{{< youtube k54FV_gl__c >}}

Here are my three favorite YouTube covers of this 1966 song by Paul Simon and Bruce Woodley. Vote for your favorite!

#1. The Snapsons (My vote for best ensemble act)

{{< youtube 0Mo01_OHNj0 >}}

#2. hopeonatenspeed (My vote for best ukelele)

{{< youtube lHGrNj6rLY0 >}}

#3. Bradlands (Another ukelele act, but best actual singing)

{{< youtube V9tHaDkW-i8 >}}

Let's hear your thoughts!
