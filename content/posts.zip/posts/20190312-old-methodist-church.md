+++
date = "2019-03-12T03:00:00+00:00"
title = "Old Methodist Church"
categories = ["Journal"]
tags = ["Pasadena","California","travel"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552362141/img/AE13A14E-DB5D-4644-B34E-A376AD0A7360.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552362141/img/AE13A14E-DB5D-4644-B34E-A376AD0A7360.jpg" >}}

The interesting things you run across when you decide to walk the mile and a half back to the hotel instead of Uber-ing. This is an old Methodist Church in the Playhouse District of Pasadena. Almost looks like an entrance to another world. A secret garden. A little foreboding perhaps. 

There was a lot about this area I’d like to explore. I’ll be back again.
