+++
title = "Cover Battle — Killing in the Name"
description = ""
date = "2020-05-29T17:27:49-05:00"
categories = ["Music"]
tags = ["YouTube","music"]
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1590791718/img/Screen_Shot_2020-05-29_at_5.34.52_PM.jpg"]
+++
{{< youtube K7i-TV45lQE >}}

Recent events got me resurrecting an old feature of the site that I've neglected far too long. Today's YouTube cover battle features Rage Against the Machine's ["Killing in the Name."](https://en.wikipedia.org/wiki/Killing_in_the_Name)
<!--more-->

This song must strike a chord because it's been covered by more people than any I've ever seen, from pros to jokers to 3-year old kids. 

I'd say its time has come.

If you're familiar with my cover battles you know my tastes lean toward the amateur but sincere, with room leftover for more offbeat professional performances. One thing, though — as a frustrated performer myself I genuinely *love* all the selections I pick, for one reason or another. I'm not laughing at any of these people, unless they're trying to be funny.

{{< youtube slPcweQ_Bg4 >}}

Apparently Asian kids freaking *love* this song something hard, cause there are a ton of them covering this track. Fight the power, guys. I really dig this family collaboration.

{{< youtube OVboY26AexU >}}

Props to Dan Dubuque for maintaining his urban rage in the middle of the Alaskan wilderness. He's even got the grizzlies pissed off at the cops. Fine performance and really cool sound.

{{< youtube wdepf8H4Lgc >}}

Performed on toys and featuring the otamatone, for all you fans.

{{< youtube mOE9fE72QLg >}}

Blog favorite Andy Rehfeldt returns with a hyper-mellow twist on an angsty nineties classic. One of my more highly rated selections, to be sure.

{{< youtube fzY3NKs4COU >}}

This one blew my mind. Amazing cover that takes the song in different directions without losing any of the talent, if a lot of the anger.

{{< youtube h_LaMpLyGkc >}}

A couple of German guys with a bizarre interpretation.

{{< youtube hyLPJrWn2dU >}}

It's like Rage Against the Machine, but with actual roaches instead of Zack de la Rocha. Haha. Just kidding. It's goats.

{{< youtube niRMlBaDNGc >}}

Just a dad with his kids in his living room with a guitar. Some pretty fancy guitar work, too. I can relate to this guy, minus the guitar talent. 

I guess what I'm saying is, I hope *I'm* never in a situation where I'm brutally and senselessly murdered by the authorities in broad daylight in front of a crowd of people.

Just saying.
