+++
date = "2019-03-11T08:00:00+00:00"
title = "Tombstone Ideas"
categories = ["Journal"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552329066/img/742D9FDB-942E-4866-B51B-A041C02A80C5.jpg"]
+++
[{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552329066/img/742D9FDB-942E-4866-B51B-A041C02A80C5.jpg" >}}](https://www.instagram.com/p/Bu2fySAn9TM/?utm_source=ig_share_sheet&igshid=1srvudvlopzvc)

What I want my tombstone to look like, except with Firewheels and dandelions.
