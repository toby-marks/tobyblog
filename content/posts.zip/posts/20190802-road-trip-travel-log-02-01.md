+++
categories = ["Journal"]
date = "2019-08-02T13:00:00-05:00"
description = ""
minipost = "true"
tags = ["travel","vacation","Albuquerque","New Mexico","Flagstaff","Arizona","Red Rock State Park"]
title = "Road Trip Travel Log 02.01"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1564771851/img/083FFD6C-DD75-4614-8570-7E486FC91746_jcqzps.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1564771851/img/083FFD6C-DD75-4614-8570-7E486FC91746_jcqzps.jpg" >}}

On the road from Albuquerque to Flagstaff, near which we turn south to Red Rock State Park in Arizona. The kids are keen to get in a hike today, the first “real” day of our vacation, as far as I’m concerned. It’s been fun watching the younger two get excited over taking pictures  from the car with the little Instax Mini. That was Kassi’s great idea. We bought Anthony around 150 exposures and his eyes got wide when I told him I wanted him to use every single one by the end of the trip. So far we just got a few pictures from the hotel, and a pretty nice one of an 18-wheeler on the road.

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1564772299/img/C880F142-2F73-495E-B2A7-53A40DCF1A88_kr0mmx.jpg" >}}
