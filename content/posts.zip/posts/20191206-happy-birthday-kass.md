+++
categories = ["Journal"]
date = 2019-12-06T22:01:00Z
description = ""
minipost = "True"
tags = ["Kassi"]
title = "Happy Birthday, Kass"
images = ["https://res.cloudinary.com/tobyblog/image/upload/a_0/v1575670025/img/59316BAD-DA4E-4A8C-BDC5-A02872C51424_chs7ka.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1575670025/img/59316BAD-DA4E-4A8C-BDC5-A02872C51424_chs7ka.jpg" >}}  
Wishing the best of birthdays to my beloved and [fellow blogger](http://kassiblogtoo.blogspot.com/). If only it could be from Hawaii again this year. I promise to make some Mai Tais this weekend to commemorate it, and maybe post some of those pics. 
