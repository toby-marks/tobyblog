+++
title = "The Real Star of Phantasm"
date = 2014-09-19T22:43:00Z
categories = ["Journal"]
tags = ["movies","Halloween"]
minipost = "true"
+++
Here you go, folks, the real star of Phantasm — *that bad-ass muscle car!* A real thing of beauty, and I'm not even that much of a car guy.

{{< youtube W9JXLz9AaOo >}}
