+++
title = "The Mask of the Red Death"
date = 2014-10-18T06:56:00Z
categories = ["Books"]
+++
{{< picture alt="" src="http://4.bp.blogspot.com/-LG5tJUTc_xU/VEJuvEURinI/AAAAAAAABis/MisjKk3frhA/s2048/IMG_2405.JPG" >}}

> The 'Red Death' had long devastated the country. No pestilence had ever been so fatal, or so hideous. Blood was its Avatar and its seal — the redness and the horror of blood. There were sharp pains, and sudden dizziness, and then profuse bleeding at the pores, with dissolution.

<!--more--> 

> With such precautions the courtiers might bid defiance to contagion. The external world could take care of itself.

> All these and security were within. Without was the "Red Death."

> His vesture was dabbled in *blood* — and his broad brow, with all the features of the face, was besprinkled with the scarlet horror.
> 
> Edgar Allen Poe, "The Masque of the Red Death"

You can read the [full story online.](http://xroads.virginia.edu/~Hyper/POE/masque.html)