+++
title = "George Michael's Jazz Noir Album"
description = "A pop exploration of jazz noir."
date = "2019-02-08T11:11:00"
externalurl = "https://www.youtube.com/watch?v=f6izqHk4ugo"
categories = ["Music"]
tags = ["jazz","pop"]
+++
A pop take on jazz noir from his best album. Many years ago Kass and I listened to this cassette so much we broke the tape. 

I hope you all are having a mellow moment, whenever it is for you. I know I am. 

I find jazz noir goes best with whiskey.

 🥃
 
{{< youtube f6izqHk4ugo >}}
