+++
categories = ["Journal"]
date = "2019-08-09T10:00:00-05:00"
description = ""
minipost = "true"
tags = ["travel","Telluride","Colorado","vacation","Arizona","Grand Canyon","Zion","Arches","Utah","Moab"]
title = "Road Trip Travel Log 09.01"
images = ["https://res.cloudinary.com/tobyblog/image/upload/a_0/v1565366894/img/FB465A3F-24CB-4DBA-83F1-3BEFBD3C3FEE_l5z2mj.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1565366894/img/FB465A3F-24CB-4DBA-83F1-3BEFBD3C3FEE_l5z2mj.jpg" >}}

Arrived in beautiful Telluride, Colorado, and yes, this is my first update since day #2 of vacation. So much for my Travel Log. Between lack of cell signal and surrendering my phone to the kid, and straight up being too busy and/or exhausted, I haven’t had much opportunity for posting. 

We’ve been busy!

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1565367158/img/C369AE06-8357-4869-915A-186467331403_h7mulf.jpg" >}}

Back to the Grand Canyon this year, and this time we got to spend a night in the park, with a chance to do some dawn/dusk shots of the canyon itself. I can’t wait to show off some of the shots that I took, not to mention the ones that Kassi got herself, which were fairly impressive. Dinner at the El Tovar was exceptional, I have to say. Love all that dark wood. No chance for any night photography due to the cloud cover which has chased us the whole trip so far. That’s actually been a blessing, as it’s tamped down the heat a bit on what we anticipated to be the hottest parts of the trip.

And just like that, I’m being called away again. Time to do more stuff. Lots happened in between, including trips to Zion and Arches!

More updates later. Gotta run!

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1565367804/img/7BC72DD6-1D4F-47E4-9AE4-0FE03B0E05FF_jpasnc.jpg" >}}
