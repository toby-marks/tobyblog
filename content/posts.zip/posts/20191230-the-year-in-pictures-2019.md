+++
title = "The Year in Pictures — 2019 Edition"
description = ""
date = "2019-12-30T16:21:55-06:00"
categories = ["Journal"]
minipost = "true"
images = ["https://live.staticflickr.com/65535/49279052183_2e46df5081_k.jpg"]
+++
[{{< picture alt="" src="https://live.staticflickr.com/65535/49279052183_2e46df5081_k.jpg" >}}](https://www.flickr.com/photos/tobyjmarks/albums/72157712375623937/with/49279052183/)

*You have unlocked bonus content!*

Welcome to this retroactively inserted yearly retrospective. The date I am writing this is actually December 30, 2020. If you've found this page, that means you've stumbled upon some content that, while genuinely old, was not originally posted on this date. Greetings from the future! Or something. I suppose I could make some joke right now warning you to "turn back" from the dread year 2020, but that whole bit seems tired and depressing.

In 2019 I opted to go for a minimalist approach for my yearly "Best Of" gallery, meaning I was apparently too lazy to sift through all my photos and make some hard choices. Tsk Tsk. I plan to revisit 2019 at some point in the future and rectify that situation. After all, we had a splendid family vacation that took us to some amazing parts of the country, and this pitiful collection of 24 photos just doesn't begin to do it justice. Not to mention this was the last year of my working stint in Pasadena, trips with Kassi to Sequoia and Channel Islands National Parks, concert photos from the Plano Balloon Festival, and whole lot more that I thankfully blogged about during the year.

Take a look!
