+++
title = "Happy Birthday, Curtis Mayfield. RIP"
description = ""
date = "2020-06-03T10:26:58-05:00"
categories = ["Music"]
tags = ["youtube","Curtis Mayfield"]
externalurl = "https://www.youtube.com/watch?v=Tm8lcTTDp0o"
+++
{{< youtube Tm8lcTTDp0o >}}

I'm afraid we're all out of Curtis Mayfields.
