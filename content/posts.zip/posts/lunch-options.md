+++
categories = ["Journal"]
date = 2020-02-26T22:00:00Z
description = ""
minipost = "True "
tags = []
title = "Lunch Options"

+++
I was at the juice bar today getting an “Immune Booster” (beet, ginger, cayenne — I could use it right now)…

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1582758180/img/84F50F39-A03C-4F08-A6A1-A813DB8CE802_nknmjy.jpg" >}}  
…when I noticed this alternative 

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1582758261/img/F9D3DF73-EEDE-4E8B-9E47-5C995AED0BCE_g2gqpq.jpg" >}}  
It was a cup of donuts. They were selling donuts by the cup. At the juice bar. 

Today, I chose wisely. 