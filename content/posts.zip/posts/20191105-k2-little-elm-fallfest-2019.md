+++
title = "Kassi Blogs the Little Elm Autumn Fest"
description = ""
date = "2019-11-05T15:35:49-06:00"
externalurl = "https://kassiblogtoo.blogspot.com/2019/11/little-elm-autumn-fest-2019.html"
categories = ["Journal"]
tags = ["Kassi"]
+++
She's right, the [Little Elm Autumn Fest](https://www.littleelm.org/1110/Autumn-Fest) was a blast. We went Friday on Oktoberfest night and the polka band was amazing, as were the food trucks and local craft beer. It was crowded, and we had to park a fair distance away, but we had a good time and were able to do what we went there to do. This is gonna be on our must-do list next year, but I think I'd like to get there earlier. 
