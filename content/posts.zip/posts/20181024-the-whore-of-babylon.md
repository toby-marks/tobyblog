+++
title = "Revelation 17"
description = "Meditation on the Whore of Babylon"
date = "2018-10-24T01:26:49-05:00"
categories = ["Journal"]
tags = ["prophecy","religion","Catholic"]
images = ["https://upload.wikimedia.org/wikipedia/commons/d/da/Burgkmair_whore_babylon_color.jpg"]
+++
{{< picture alt="" src="https://upload.wikimedia.org/wikipedia/commons/d/da/Burgkmair_whore_babylon_color.jpg" >}}

## A meditation on a figure of the last days.

📖  Revelation 17, KJV

And there came one of the seven angels which had the seven vials, and talked with me, saying unto me, Come hither; I will shew unto thee the judgment of the great whore that sitteth upon many waters: with whom the kings of the earth have committed fornication, and the inhabitants of the earth have been made drunk with the wine of her fornication.
<!--more-->

So he carried me away in the spirit into the wilderness: and I saw a woman sit upon a scarlet coloured beast, full of names of blasphemy, having seven heads and ten horns. And the woman was arrayed in purple and scarlet colour, and decked with gold and precious stones and pearls, having a golden cup in her hand full of abominations and filthiness of her fornication: and upon her forehead was a name written, MYSTERY, BABYLON THE GREAT, THE MOTHER OF HARLOTS AND ABOMINATIONS OF THE EARTH. And I saw the woman drunken with the blood of the saints, and with the blood of the martyrs of Jesus: and when I saw her, I wondered with great admiration.

And the angel said unto me, Wherefore didst thou marvel? I will tell thee the mystery of the woman, and of the beast that carrieth her, which hath the seven heads and ten horns.

The beast that thou sawest was, and is not; and shall ascend out of the bottomless pit, and go into perdition: and they that dwell on the earth shall wonder, whose names were not written in the book of life from the foundation of the world, when they behold the beast that was, and is not, and yet is.

And here is the mind which hath wisdom. The seven heads are seven mountains, on which the woman sitteth. And there are seven kings: five are fallen, and one is, and the other is not yet come; and when he cometh, he must continue a short space. And the beast that was, and is not, even he is the eighth, and is of the seven, and goeth into perdition. And the ten horns which thou sawest are ten kings, which have received no kingdom as yet; but receive power as kings one hour with the beast. These have one mind, and shall give their power and strength unto the beast. These shall make war with the Lamb, and the Lamb shall overcome them: for he is Lord of lords, and King of kings: and they that are with him are called, and chosen, and faithful.

And he saith unto me, The waters which thou sawest, where the whore sitteth, are peoples, and multitudes, and nations, and tongues. And the ten horns which thou sawest upon the beast, these shall hate the whore, and shall make her desolate and naked, and shall eat her flesh, and burn her with fire. For God hath put in their hearts to fulfil his will, and to agree, and give their kingdom unto the beast, until the words of God shall be fulfilled.

And the woman which thou sawest is that great city, which reigneth over the kings of the earth.

☦︎  ☦︎  ☦︎

