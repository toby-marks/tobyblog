+++
date = "2019-04-06T20:00:00+00:00"
title = "Flip Wilson"
categories = ["Journal"]
tags = ["toys"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1554601645/img/8288B849-0F88-43DA-ACD9-BB1BBDF19A23.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1554601645/img/8288B849-0F88-43DA-ACD9-BB1BBDF19A23.jpg" >}}

Today I passed up the opportunity to buy a vintage talking Flip Wilson doll that would tell me not to touch him inappropriately. #70s #beforenintendo
