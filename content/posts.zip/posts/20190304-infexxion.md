+++
title = "Infexxion-34"
date = "2019-03-04T23:29:44-06:00"
categories = ["Journal"]
tags = ["gaming"]
images = ["https://live.staticflickr.com/7825/46298055565_a3db27735c_k.jpg"]
minipost = true
+++
Infexxion is an iPhone game based on the old arcade game [Attax](https://en.wikipedia.org/wiki/Ataxx). My cousin Carl introduced me to [it](https://www.youtube.com/watch?v=L-CTpCD-CNc). There was a cabinet in the lobby of a (surely long-since demolished?) movie theater in what is now a rough part of Lafayette, Louisiana. I forget what we were seeing that night. He played — I didn't, as I recall. It had a weird, edgy kind of quality to it, like an [Exidy game](https://www.youtube.com/watch?v=giobpyH6FnY). It's addictive. The only place I've seen it since is [Freeplay Arcade](http://freeplayrichardson.com/) in Richardson, Texas, where if you can beat the final "boss" AI, you get a free beer. 

*One* time, just a few weeks after discovering Infexxion, I scored a 40. I've been playing that game for over a year now. In all that time, I have never matched or beaten that score.

Not a single time. 

{{< picture alt="Infexxion" src="https://live.staticflickr.com/7825/46298055565_76fe293a6c_k.jpg" >}}
