+++
categories = ["Music"]
date = "2019-05-04T05:00:00+00:00"
description = ""
externalurl = "https://youtu.be/Zavu4__KuBo"
minipost = true
tags = ["jazz"]
title = "Uncle Albert"
+++
Currently enjoying at maximum volume.

{{< youtube Zavu4__KuBo >}}
