+++
title = "Once Upon a Time, Frank Sinatra"
description = "Current mood."
date = "2018-10-17T16:17:27-05:00"
externalurl = "https://www.youtube.com/watch?v=lTqI7Y7vm2c"
tags = ["Frank Sinatra"]
categories = ["Music"]
+++
{{< youtube lTqI7Y7vm2c >}}
