+++
title = "This Soft Jazz Will Cure Your Coronavirus"
description = ""
date = "2020-03-20T09:55:49-05:00"
categories = ["Music"]
tags = ["coronavirus","covid-19"]
externalurl = "https://www.youtube.com/watch?v=B9o57ptzytU"
+++
I guess it's true that there really *is* a jazz for every conceivable mood or situation.

{{< youtube B9o57ptzytU >}}