+++
categories = ["Journal"]
date = "2019-04-15T00:00:00+00:00"
description = ""
minipost = true
tags = ["travel","Pasadena","California"]
title = "Roof Access"
images = ["https://res.cloudinary.com/tobyblog/image/upload/a_0/v1555471935/img/7E8FD61C-07C1-49E8-8102-9DD118A4FABD.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1555471935/img/7E8FD61C-07C1-49E8-8102-9DD118A4FABD.jpg" >}}

I get irrationally excited when I see ROOF ACCESS. But it’s never actually accessible.
