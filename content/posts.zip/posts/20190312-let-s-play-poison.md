+++
date = "2019-03-12T02:00:00+00:00"
title = "Let’s Play Poison"
categories = ["Journal"]
tags = ["travel","Pasadena","California","television"]
minipost = true
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1552360872/img/8C748FE3-CF0B-45E7-BB87-808D68405F04.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1552360872/img/8C748FE3-CF0B-45E7-BB87-808D68405F04.jpg" >}}

There's someone buried under there. That's the name. And see the date? [Poison! Get off!](https://www.youtube.com/watch?v=ZbC4NKCNm5E)
