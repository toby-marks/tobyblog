+++
title = "A Fire Sign"
date = "2019-07-11T12:01:00-05:00"
description = ""
minipost = "true"
categories = ["Journal"]
tags = []
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1562867894/img/A7927185-F07D-438E-974C-C68933D42DCD.jpg"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1562867894/img/A7927185-F07D-438E-974C-C68933D42DCD.jpg" >}}

The name of this sculpture is Entwine, I think a reference to The Lord of the Rings. It’s supposed to be a tree, or plant, to symbolize Wylie’s connection to its roots. I always thought of it as a campfire, and I think that imagery fits much better for a library.
