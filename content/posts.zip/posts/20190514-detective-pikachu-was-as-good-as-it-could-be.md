+++
categories = ["Reviews"]
date = "2019-05-14T20:02:00+00:00"
description = "Go see Detective Pikachu!"
externalurl = ""
minipost = true
tags = ["Pokemon", "movies"]
title = "Detective Pikachu Was As Good As It Could Be"
images = ["https://res.cloudinary.com/tobyblog/image/upload/v1557888093/img/5F86E6CC-37E8-4256-BC38-E41AFDFCE5A8.gif"]
+++
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1557888093/img/5F86E6CC-37E8-4256-BC38-E41AFDFCE5A8.gif" >}}

In other news, I saw Detective Pikachu with the family a few days ago, and I think we all left impressed. Some strong acting and genuinely funny moments. Pikachu singing the Pokémon cartoon theme song was a highlight for me. But does Ryan Reynolds have to be in literally every movie now? That being said, he did a wonderful job. A really enjoyable and charming movie. Go see it. With your kids, of course.
