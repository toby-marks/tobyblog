+++
title = "Sounds From a Mall"
description = ""
date = "2019-07-11T12:32:05-05:00"
categories = ["Audio"]
tags = [""]
minipost = "true"
+++
The second installment in my ongoing series of ambient environmental sound recordings. These are the sounds of me packing up my recorder and walking to the food court, where I order a bowl from Chipotle. I take my bowl outside to the patio to enjoy the fresh air and sunshine, after which I take a little walk around the mall to pick up some interesting sounds. And for the second time in a row I ran across a guy playing a piano. Coincidence? Not sure, but it would be cool if that happened every time and everywhere I tried this.

Hope you enjoy.

{{< youtube DbZjXsbFDfA >}}
