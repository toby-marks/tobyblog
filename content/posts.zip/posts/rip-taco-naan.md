+++
title = "Rip Taco Naan"
description = ""
date = "2020-12-05T09:25:06-06:00"
minipost = "true"
categories = [""]
tags = [""]
+++

Damn you, covid. And damn the lockdowns.

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/v1607180380/img/Screen_Shot_2020-12-03_at_5.11.58_PM.jpg" >}}

Small businesses are an unaccounted for casualty of 2020. The vast majority cannot survive indefinite periods of marginal revenue due to generalized fear or service restrictions. The money that would have gone to them are instead funneled to large businesses and the mega-rich like Bezos. At least there has been some kickback with regards to people being put out of their homes because of an inability to pay rent (and that may change). But not much has been offered to small businesses except for loans — there is no serious talk of debt relief for them or for people put out of work by the virus. So the best case scenario is to emerge from a couple of years of reduced earnings with a mountain of crushing debt. 

To be fair that is, perhaps, a lack of leadership that can be blamed on Trump. But nothing new in terms of policy is being offered by the Biden administration. There are no  solutions proposed other than the soft mandate of vaccines that have undergone minimal and hurried testing and claim to do something no other vaccine in history has ever successfully done, which is inoculate against a coronavirus. We are being asked to be guinea pigs in a scientific experiment that enriches big pharmaceutical companies, in order to fix a problem that the government created, with the threat that our lives will never return "to normal" unless we comply.

All that to say Taco Naan is gone. 

From my very first [review]({{< ref "20140226-taco-naan-review.md" >}}) of the place, to the times I spent taking pictures of [random lunches]({{< ref "20190507-taco-naan-lunch.md" >}}) in my car, to the time I actually invented a [secret menu item]({{< ref "20160811-the-bollywood-burrito.md" >}}), to the times I was able to [share the place with my friends](http://www.reviewtheworld.com/2015/03/texas-taco-challenge-taco-naan-vs-fuel.html), Taco Naan was always nothing less than a delight and a sunny spot on a [rainy day.]({{< ref "microposts/taco-naan-in-the-rain.md" >}})

Taco Naan, I'll miss you. May the flavor live on.

{{< youtube WEDVIb79Q3k >}}
