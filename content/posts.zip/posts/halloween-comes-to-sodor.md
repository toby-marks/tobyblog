+++
title = "Halloween Comes to Sodor"
date = 2015-10-24T21:49:00Z
updated = 2015-10-24T21:49:13Z
draft = true
blogimport = true 
[author]
	name = "Toby Marks"
	uri = "https://www.blogger.com/profile/09367177211408746652"
+++

<div class="separator" style="clear: both; text-align: center;"><a href="http://4.bp.blogspot.com/-6Z5hs35FRLg/VixTeLnYyjI/AAAAAAAACuY/qd9svWUS0Kw/s2048/Screen%2BShot%2B2015-10-24%2Bat%2B10.58.06%2BPM.png" imageanchor="1" style="margin-left: 1em; margin-right: 1em;"><img border="0" src="http://4.bp.blogspot.com/-6Z5hs35FRLg/VixTeLnYyjI/AAAAAAAACuY/qd9svWUS0Kw/s900/Screen%2BShot%2B2015-10-24%2Bat%2B10.58.06%2BPM.png" /></a></div><div class="separator" style="clear: both; text-align: left;"><br /></div><div class="separator" style="clear: both; text-align: left;">I have three kids. All of them were at some point into Thomas the Train, and none more so than the littlest. As a result I have become well acquainted with the mythical island of Sodor and its very useful residents.&nbsp;</div><div class="separator" style="clear: both; text-align: left;"><br /></div><div class="separator" style="clear: both; text-align: left;">The TV show is legendary, but the quality slipped in recent years after the switch to CG animation. In addition to dropping the original British voice actors they morphed Thomas's character into some kind of whiny juvenile. Frankly, it's annoying. So one day I looked into alternatives on YouTube.</div><div class="separator" style="clear: both; text-align: left;"><br /></div><div class="separator" style="clear: both; text-align: left;">Turns out there are loads of fan videos using the Thomas characters and universe, <i>some better than the original</i>!&nbsp;</div><div class="separator" style="clear: both; text-align: left;"><br /></div><div class="separator" style="clear: both; text-align: left;">Seriously, there is a metric crap-ton of Thomas vids out there</div><div class="separator" style="clear: both; text-align: left;"><br /></div><div class="separator" style="clear: both; text-align: left;"><br /></div>
