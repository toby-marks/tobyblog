+++
title = "August into December at the Holiday Warehouse"
date = 2016-09-11T13:36:00Z
categories = ["reviews"]
tags = ["Decorator's Warehouse", "fall", "Christmas", "Thanksgiving", "halloween", "Holiday Warehouse", "winter","stores"]
images = ["https://live.staticflickr.com/8430/29188949732_55bd1cfc2f_o.jpg"]
+++
{{< picture alt="Mr. Pumpkin" src="https://live.staticflickr.com/8430/29188949732_55bd1cfc2f_o.jpg" >}}

The [Holiday Warehouse" src="http://www.holidaywarehouse.com/) is a largish, and rather outstanding, independent holiday decor shop located in Plano, Texas. Like its well known cousin The [Decorator's Warehouse" src="{{< ref "20150826-the-decorators-warehouse.md" >}}) in Arlington, the concentration is mainly on Christmas, but not as exclusively.

<!--more-->

{{< picture alt="Witch Ribbon" src="https://live.staticflickr.com/8553/28676038423_9afcc4b808_o.jpg" >}}

Past rooms full of Santas, red ribbon, and nativities is the deep orange and pumpkin be-decked fall room, and finally the little section reserved for the Halloween stock, the inclusion of which sets this place apart from the store in Arlington.

{{< picture alt="The Dark Lady" src="https://live.staticflickr.com/8119/29188948242_801acf1860_o.jpg" >}}

This dark lady stands sentinel outside the door, promising delights both elegant and shadow-veiled.

{{< picture alt="Skull Pumpkin" src="https://live.staticflickr.com/8546/28676041883_9a1feb66d2_o.jpg" >}}

Calling back to my favorite abandoned blog of all time, this fellow both teased and excited me, as I have wanted to do something similar as a jack o' lantern carving for many years now. Perhaps this will be the year.

{{< picture alt="Bride and Groom" src="https://live.staticflickr.com/7773/28676046163_f8153860fb_o.jpg" >}}

Skeletons are always a strong theme for Halloween, as they remind us of death and mortality. So the juxtaposition of those elements with the nuptial symbols here, signs of youth and fertility, lend this piece a certain poignancy, don't you think?

{{< picture alt="Bling Skull" src="https://live.staticflickr.com/8532/28676045173_697b33c1d2_o.jpg" >}}

Holiday Warehouse considers itself both "upscale" and "aspirational", so this bling-y skull seems about right. Though I've seen similar gaudy items at Michaels and At Home this year. It's a theme for 2016. Because of Trump?

{{< picture alt="No Pictures" src="https://live.staticflickr.com/8212/28674408514_44871f29a6_o.jpg" >}}

This guy was either telling me to get my camera out of his face and move along, or else setting up for a high five. I couldn't decide.

{{< picture alt="Skeleton Ball" src="https://live.staticflickr.com/8371/29188946362_0869436bc8_o.jpg" >}}

Truthfully there were many items that looked appropriate for some sort of elaborate New Orleans masquerade ball. Made me wonder how many such parties there are in Plano come October.

{{< picture alt="Vampire" src="https://live.staticflickr.com/8388/28676047713_4135ef7a97_o.jpg" >}}

This vampire, high up on a top shelf, was of that ilk. With his little silk vest and lace trim, if this dapper guy wasn't Dracula, then presumably he was the Count of _something_.

{{< picture alt="Undead Girl" src="https://live.staticflickr.com/7502/29296838735_01bb9ec85a_o.jpg" >}}

Don't make the mistake of backing into this little girl, as I did. Because whipping around to find this staring at you can be a pit of a shock. This is the kind of thing that would feel right at home at the old Collector's Crypt. It's a good  example of the variety of stock carried by the Holiday Warehouse.

{{< picture alt="Zombie Face" src="https://live.staticflickr.com/8808/29263058606_0326242d49_o.jpg" >}}

As is this weird guy, who I caught staring at me from a basket of hanging door decorations.

{{< picture alt="Los Muertos" src="https://live.staticflickr.com/8403/28676048583_0803ba1994_o.jpg" >}}

The Mexican holiday of Los Dias de los Muertos is gaining visibility in the States the past few years, as it rightfully should. People see it as exotic and macabre, but it's nothing more than the traditional observance of the Catholic feasts of All Saints and All Souls, albeit with a Mexican flare.

{{< picture alt="Los Muertos" src="https://live.staticflickr.com/7736/28676049393_b146d07567_o.jpg" >}}

The calaveras, the candied skulls and brightly decorated skeletons are a reminder of the transitory nature of human life, and of the love we always share with our dearly departed. The fear of death, and its ugliness, is transformed into love and beauty through the redemptive power of Christ's resurrection, in which the faithful hope to share. It's far from morbid. These little statues had a certain grace, fine detail, and surprisingly not too expensive.

{{< picture alt="Skulls" src="https://live.staticflickr.com/7645/29218355901_3630df2f52_o.jpg" >}}

More on the meditative end of the spectrum were these stacked skulls, which I may yet walk away with as a piece for the fireplace.

{{< picture alt="Graveyard Altar" src="https://live.staticflickr.com/8096/29218359741_57c35cfb9f_o.jpg" >}}

These little cemetery scenes caught my eye for their intricate detail and strange symbolism. It the dog on the altar had been a bulldog, I would have bought it on the spot.

{{< picture alt="Halloween Yard Decorations" src="https://live.staticflickr.com/8316/29218361531_e1c16ec3d0_o.jpg" >}}

The place does fancy really well, but there's also rustic here and there, like these artificially weathered old yard signs, which I have to admit look pretty cool.

{{< picture alt="Pumpkin Witch" src="https://live.staticflickr.com/8273/29218367461_57a1961196_o.jpg" >}}

Did I somebody say fancy? This healthy looking pumpkin witch is all set to hand out candy at your next Halloween costume ball, and maybe a couple of steins of beer as well.

{{< picture alt="Bowl of Skulls" src="https://live.staticflickr.com/8471/29218372251_c2aa1ef486_o.jpg" >}}

I told you bling-y skulls were in this year. But what's better than a bling-y skull? A bowlful of elaborately embossed, authentic brass skulls, of course.

{{< picture alt="Gargoyles" src="https://live.staticflickr.com/8230/29263060166_906048875f_o.jpg" >}}

Gargoyles are a Halloween theme that need to make a comeback, in my opinion. When I was a kid I remember gargoyles being a much bigger deal. But I watched a lot of Scooby Doo.

{{< picture alt="Mr. Pumpkin" src="https://live.staticflickr.com/8043/28674405584_18d4ac028d_o.jpg" >}}

Back out in the hall I had a stop and gawk at Mr. Pumpkin for a bit. It's a little hard to tell from the photograph, but this thing must stand like six feet tall. And I can only imagine that the cost of all his fall-flavored finery must be many times that of the nicest suit I've ever worn. He was exquisite, that guy.

{{< picture alt="Tom Turkey" src="https://live.staticflickr.com/8200/28676039923_9d519b2b3b_o.jpg" >}}

And lest you think old Tom Turkey gets slighted, forget it. He was there in many manifestations, in all his November glory. This particular model cost over a thousand dollars and stood about three feet tall. He was obviously some sort of table centerpiece and looked so grand I had to take a selfie with him. (Selfie not shown).

{{< picture alt="St. Joseph and Wise Man" src="https://live.staticflickr.com/8200/29218417611_05fe93eb16_o.jpg" >}}

On the way back out of the store we traveled quickly from November to December, where we stopped for a minute to admire the selection of enormous and truly beautiful nativity sets on display.

{{< picture alt="Fontanini" src="https://live.staticflickr.com/8156/29218425201_48bb612493_o.jpg" >}}

We were informed that the Pope owns this very set, and displays it at the Vatican in Rome. I'm not sure which pope, but presumably Pope Francis. Honestly, it looked good enough.

{{< picture alt="Wise Man" src="https://live.staticflickr.com/8874/29218418251_69921c5476_o.jpg" >}}

The figures were all incredibly life-like, and bore varying expressions of nobility, joy, and a kind of worshipful purpose.

{{< picture alt="Balthasar" src="https://live.staticflickr.com/8087/29218418941_9c22590385_o.jpg" >}}

Golden eyes were a strange, confronting choice for old Balthasar! But it works. The statue's gaze is very intense, and overall the impression is very life-like.

{{< picture alt="St. Joseph" src="https://live.staticflickr.com/8192/29218421581_35a0e34587_o.jpg" >}}

St. Joseph gazes down in thoughtful adoration…

{{< picture alt="The Virgin Mary" src="https://live.staticflickr.com/8321/29218420951_82489c53b6_o.jpg" >}}

…while the Virgin Mary seems enraptured at the sight of the baby Jesus. So well done, so well crafted.

{{< picture alt="Baby Jesus" src="https://live.staticflickr.com/8587/29218419901_b4740f296d_o.jpg" >}}

Little baby Jesus seemed the weakest part of the set, unfortunately. His head was a little too small. His arms and legs are all out of proportion. It's meant to be artistically devotional, but it should have been a tad more lifelike, in my opinion.

{{< picture alt="The Blessed Virgin Mary" src="https://live.staticflickr.com/8175/29218422781_f582ded617_o.jpg" >}}

A different set, with a strikingly beautiful representation of the Blessed Virgin. The cradle on that day was vacant, filled only with decorative shrubbery. Too bad. Would have liked to have seen more of this set.

Goodbye for now! Hope reading through all this has given you a little taste of holiday spirit, courtesy of the Holiday Warehouse. Like what you've seen? Here's a link [to the online store" src="http://www.holidaywarehouse.com/halloween/). More to come.
