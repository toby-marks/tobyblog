+++
title = "Music From Empty Malls"
description = ""
date = "2020-06-18T11:19:10-05:00"
categories = ["Music"]
tags = ["youtube", "malls"]
externalurl = "https://www.youtube.com/playlist?list=PL9equyYLLq5xEkM9oFLPIey0aHrO0q5Hv"
+++
My working playlist for today. Makes me think about remoting from the old [Collin Creek mall]({{< ref "20190523-the-holdouts-of-collin-creek.md" >}}). I miss that place.

<iframe width="100%" height="300" src="https://www.youtube.com/embed/videoseries?list=PL9equyYLLq5xEkM9oFLPIey0aHrO0q5Hv" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
