+++
title = "From Vermeule to Newman"
description = "The problem with erudite Catholic bloggers"
date = "2018-10-26T00:38:10-05:00"
externalurl = "https://semiduplex.com/2018/10/22/from-vermeule-to-newman/"
categories = ["Journal"]
tags = ["religion","Catholic"]
+++
>Even if Francis is a liberal, it is far from clear to us that the proper response is liberalism. This, then, is the crux of the problem. Barring the Head of the Church returning, there will be other popes. Perhaps some will be, in the words of the great Louisiana philosopher and theologian I.J. Reilly, good authoritarian popes. Perhaps some will be liberals. However, the anti-liberal position works as well with a good authoritarian pope as it does with a liberal pope. Indeed, it works even better. And it has the advantage of avoiding a perpetual oscillation between ultramontanism and neo-Gallicanism.

The problem with these types of erudite professional religionists is that they often cannot see the truth, because they do not see with the eyes of the spirit. The church is rotting, the flies are gathering, and they argue about whether it is right to criticize the pope. 