+++
title = "Show Some Love To My Spouseblog"
description = ""
date = "2019-07-07T17:41:06-05:00"
categories = ["Journal"]
tags = ["Kassi"]
externalurl = "https://kassiblogtoo.blogspot.com/2019/07/my-growing-library-of-john-muir-writings.html"
+++
If you haven't been following Kassi over on her personal blog, by all means go there and check it out. She's been killing it lately, posting about all the family stuff I'm supposed to be getting to over on this site, but have been too lame to do. I swear she can fire off 3 or 4 posts by the time I'm done editing the same number of photos. Practice, I guess? Her latest one about the John Muir books she's been collecting has put me in a very vacation-y kind of mood. I thought it was funny that she called me out for still working on photos from two years ago, which is true. But I have learned (what I think is) a whole lot in the meantime, and my camera and software suite, and hopefully my editing sensibilities, have evolved a great deal in that time. It's been fun revisiting those not-so-old photos and reminiscing on the times we spent out on the road in some very rugged country. I'd honestly forgotten just how pretty it was up in Colorado the summer of 2017. Anyway, enjoy the blog and hopefully get inspired yourself. John Muir was a great man, one of this nation's finest. And more to come here on all that as well.
