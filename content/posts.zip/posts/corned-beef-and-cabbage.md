+++
categories = ["Photoblog"]
date = 2020-03-18T01:00:00Z
description = ""
minipost = "True"
tags = []
title = "Corned Beef and Cabbage"

+++
A traditional Irish dinner. Corned beef and cabbage and Saldo. (Well maybe not that last bit...)  
  
{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1584496719/img/5E5575D6-6C0C-4F76-A627-A92BE653AA03_lmhqbf.jpg" >}}

Yes, it’s a cheat during Great Lent. But it’s also a long established family tradition. And St. Patrick is a special patron of ours. 

{{< picture alt="" src="https://res.cloudinary.com/tobyblog/image/upload/a_0/v1584496894/img/4FABD799-B14F-4D46-A2D9-7F2DE1BEAB97_iw970m.jpg" >}}

For dessert, s’mores over the stove, as we missed our chance for brownies today, and I neglected to hoard ice cream during the quarantine. No matter, they were delicious. 

Happy St. Pat’s. How about celebrating with a [Stinger](https://www.esquire.com/food-drink/drinks/recipes/a3762/stinger-drink-recipe/) tonight?