+++
title = "Corona Virus Rap - Gmac Cash"
description = ""
date = "2020-03-28T10:52:59-05:00"
categories = ["Music"]
tags = ["coronavirus","covid19"]
externalurl = "https://www.youtube.com/watch?v=OGQm0nQcJXA"
+++
While I'm at it I might as well post this, too, since Josh got such a kick out of it. I sent this to him a week or so ago, then days later he's in the hospital. Great timing on my part. Maybe he didn't follow soon enough the sober and thoughtful advice given in this video. 

Get well, my brother.

{{< youtube OGQm0nQcJXA >}}