+++
title = "Our Choice"
description = "The choice we all have."
date = "2019-02-18T23:11:34-08:00"
categories = ["Journal"]
tags = ["religion","Orthodox"]
images = ["/img/IMG_1698.JPG"]
minipost = "true"
+++

{{< picture src="images/IMG_1698.jpg" >}}
