+++
title = "Conversations 2 – Thoughts on the Wii U"
date = 2016-04-15T16:04:00Z
categories = ["Gaming"]
tags = ["Augie"]
minipost = "true"
+++
{{< soundcloud 258460993 >}}

TheVCubeSolver and I talk about the things we love about the Nintendo Wii U on a long drive home.
